
/*import React, { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

const BACKEND_URL = 'http://localhost:8000'; 

export default function Home({ user, onLogout }) {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  
  // DYNAMIC USER DATA: Pulling from the 'user' prop
  // If user.name is missing, we use the part of the email before the @
  const displayName = user?.name || (user?.email ? user.email.split('@')[0] : "Guest");
  const userEmail = user?.email || "";

  // Close dropdown if clicked outside
  useEffect(() => {
    function handleClickOutside(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim() !== "") {
      navigate(`/search-results?q=${encodeURIComponent(query)}`);
    }
  };

  return (
    <div style={containerStyle}>
   
      <nav style={navbarStyle}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <span style={{ fontWeight: '500', color: '#555' }}>Priority Pass</span>
          <span style={{ color: '#888', cursor: 'pointer' }}>💬</span>
        </div>

        <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
          {!user ? (
            <div style={{ display: 'flex', gap: '10px' }}>
              <Link to="/login" style={authBtnStyle('#007bff')}>Login</Link>
              <Link to="/register" style={authBtnStyle('#28a745')}>Register</Link>
            </div>
          ) : (
            <div style={{ position: "relative" }} ref={dropdownRef}>
          
              <div onClick={() => setDropdownOpen(!dropdownOpen)} style={profileTriggerStyle}>
                <div style={avatarStyle}>
                  {displayName.charAt(0).toUpperCase()}
                </div>
                <span style={{ fontSize: '10px', color: '#03a9f4' }}>
                  {dropdownOpen ? '▲' : '▼'}
                </span>
              </div>

              {dropdownOpen && (
                <div style={dropdownCardStyle}>
                  <div style={{ padding: '15px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                     
                      <span style={{ fontWeight: 'bold', textTransform: 'capitalize' }}>
                        {displayName}
                      </span>
                      <span style={{ color: '#03a9f4' }}>✔️</span>
                    </div>
                  
                    <div style={{ fontSize: '12px', color: '#777' }}>{userEmail}</div>
                  </div>
                  
                  <div style={dividerStyle} />
                  
                  <div style={{ padding: '12px 15px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <span style={{ color: '#ffc107' }}>★</span>
                      <span style={{ fontWeight: 'bold' }}>5</span>
                    </div>
                    <Link to="/achievements" style={knowMoreLink} onClick={() => setDropdownOpen(false)}>
                        Know More ➔
                    </Link>
                  </div>

                  <div style={dividerStyle} />

                  <div style={{ padding: '5px 0' }}>
                    <button onClick={() => { navigate("/dashboard"); setDropdownOpen(false); }} style={menuBtnStyle}>Dashboard</button>
                    <button onClick={() => { navigate("/skill-gap"); setDropdownOpen(false); }} style={menuBtnStyle}>Skill Gap Analysis</button>
                    <button onClick={() => { onLogout(); setDropdownOpen(false); }} style={{...menuBtnStyle, color: 'red'}}>Logout</button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </nav>


      <div style={heroSectionStyle}>
        <h1 style={heroTitleStyle}>Course Recommender</h1>
        <p style={heroSubtitleStyle}>Discover the best courses for your skills and goals</p>
        
        <button onClick={() => navigate("/skill-gap")} style={skillGapBtnStyle}>
          Skill Gap Analysis
        </button>

        <form onSubmit={handleSearch} style={searchFormStyle}>
          <input
            type="text"
            placeholder="Search courses or skills..."
            style={searchInputStyle}
            onChange={(e) => setQuery(e.target.value)}
          />
          <button type="submit" style={searchSubmitBtnStyle}>Search</button>
        </form>
      </div>

      <footer style={footerStyle}>
        <p>© 2026 Course Recommender Platform</p>
      </footer>
    </div>
  );
}

// --- REUSABLE STYLES ---
const containerStyle = { minHeight: "100vh", display: "flex", flexDirection: "column", fontFamily: "Arial, sans-serif" };
const navbarStyle = { display: 'flex', justifyContent: 'space-between', padding: '10px 40px', backgroundColor: '#fff', borderBottom: '1px solid #eee', alignItems: 'center' };
const authBtnStyle = (bgColor) => ({ padding: "8px 16px", backgroundColor: bgColor, borderRadius: "4px", textDecoration: "none", color: "#fff", fontWeight: "bold", fontSize: "14px" });
const profileTriggerStyle = { display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', padding: '4px 8px', borderRadius: '4px', backgroundColor: '#f0faff' };
const avatarStyle = { width: '30px', height: '30px', borderRadius: '50%', backgroundColor: '#03a9f4', color: '#fff', display: 'flex', justifyContent: 'center', alignItems: 'center', fontWeight: 'bold' };
const dropdownCardStyle = { position: 'absolute', right: 0, top: '45px', width: '250px', backgroundColor: '#fff', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', borderRadius: '8px', zIndex: 100 };
const dividerStyle = { height: '1px', backgroundColor: '#eee', width: '100%' };
const knowMoreLink = { color: '#03a9f4', textDecoration: 'none', fontSize: '13px', fontWeight: 'bold' };
const menuBtnStyle = { width: '100%', padding: '10px 15px', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', fontSize: '14px' };
const heroSectionStyle = { flex: 1, display: "flex", flexDirection: "column", alignItems: "center", padding: "80px 20px", textAlign: "center", backgroundImage: 'linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url(https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1950&q=80)', backgroundSize: 'cover', backgroundPosition: 'center', color: "#fff" };
const heroTitleStyle = { fontSize: "3.5rem", color: "#ffeb3b", textShadow: "2px 2px 8px rgba(0,0,0,0.7)", margin: "0 0 10px 0" };
const heroSubtitleStyle = { fontSize: "1.2rem", marginBottom: "30px" };
const skillGapBtnStyle = { padding: '12px 25px', backgroundColor: '#28a745', color: '#fff', border: 'none', borderRadius: '5px', fontWeight: 'bold', cursor: 'pointer', marginBottom: '30px' };
const searchFormStyle = { display: "flex", width: "90%", maxWidth: "600px", marginBottom: "50px" };
const searchInputStyle = { flex: 1, padding: "15px", borderRadius: "5px 0 0 5px", border: "none", outline: "none", fontSize: "1rem" };
const searchSubmitBtnStyle = { padding: "15px 30px", backgroundColor: "#ff6600", color: "#fff", border: "none", borderRadius: "0 5px 5px 0", cursor: "pointer", fontWeight: "bold" };
const footerStyle = { width: "100%", padding: "20px", textAlign: "center", backgroundColor: "rgba(0,0,0,0.8)", color: "#fff" };*/
import React, { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Home({ user, onLogout }) {
  const [query, setQuery] = useState("");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [isJourneyOpen, setIsJourneyOpen] = useState(false); 
  const [isAchievementsOpen, setIsAchievementsOpen] = useState(false);
  const [stats, setStats] = useState({ streak: 0, quizzesPassed: 0, badges: 0, history: [] });
  
  const dropdownRef = useRef(null);
  const navigate = useNavigate();

  // DYNAMIC USER DATA
  const displayName = user?.name || (user?.email ? user.email.split('@')[0] : "Guest");
  const userEmail = user?.email || "";

  // FEATURE RESTORED: Close dropdown if clicked outside
  useEffect(() => {
    function handleClickOutside(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // FEATURE RESTORED: Search Logic
  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim() !== "") {
      navigate(`/search-results?q=${encodeURIComponent(query)}`);
    }
  };

  // Fetch Logic for Achievements
  const openAchievements = async () => {
    try {
      const resActivity = await fetch(`http://localhost:8000/users/${user.email}/activity`);
      const dataActivity = await resActivity.json();
      setStats({
        streak: dataActivity.streak || 0,
        quizzesPassed: dataActivity.learning_path?.length || 0,
        history: dataActivity.learning_path || []
      });
      setIsAchievementsOpen(true);
    } catch (err) {
      console.error("Failed to load achievements", err);
      setIsAchievementsOpen(true);
    }
  };

  return (
    <div style={containerStyle}>
      {/* --- NAVBAR --- */}
      <nav style={navbarStyle}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <span style={{ fontWeight: 'bold', color: '#333' }}>Priority Pass</span>
          <span style={{ color: '#888', cursor: 'pointer' }}>💬</span>
        </div>

        <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
          {!user ? (
            <div style={{ display: 'flex', gap: '10px' }}>
              <Link to="/login" style={authBtnStyle('#007bff')}>Login</Link>
              <Link to="/register" style={authBtnStyle('#28a745')}>Register</Link>
            </div>
          ) : (
            <div style={{ position: "relative" }} ref={dropdownRef}>
              <div onClick={() => setDropdownOpen(!dropdownOpen)} style={profileTriggerStyle}>
                <div style={avatarStyle}>{displayName.charAt(0).toUpperCase()}</div>
                <span style={{ fontSize: '10px', color: '#03a9f4' }}>{dropdownOpen ? '▲' : '▼'}</span>
              </div>

              {/* --- DROPDOWN MENU --- */}
              {dropdownOpen && (
                <div style={dropdownCardStyle}>
                  <div style={{ padding: '15px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ fontWeight: 'bold', textTransform: 'capitalize' }}>{displayName}</span>
                      <span style={{ color: '#03a9f4' }}>✔️</span>
                    </div>
                    <div style={{ fontSize: '12px', color: '#777' }}>{userEmail}</div>
                  </div>
                  <div style={dividerStyle} />
                  
                  <div style={{ padding: '12px 15px', display: 'flex', justifyContent: 'space-between' }}>
                    <div style={{ display: 'flex', gap: '5px' }}>⭐ <b>5</b></div>
                    <span style={knowMoreLink} onClick={() => { setIsJourneyOpen(true); setDropdownOpen(false); }}>
                      Know More ➔
                    </span>
                  </div>
                  
                  <div style={dividerStyle} />
                  
                  <div style={{ padding: '5px 0' }}>
                    <button onClick={() => { navigate("/dashboard"); setDropdownOpen(false); }} style={menuBtnStyle}>Dashboard</button>
                    <button onClick={() => { navigate("/skill-gap"); setDropdownOpen(false); }} style={menuBtnStyle}>Skill Gap Analysis</button>
                    
                    {/* Feature: View My Journey */}
                    <button onClick={() => { setIsJourneyOpen(true); setDropdownOpen(false); }} style={{...menuBtnStyle, color: '#f39c12', fontWeight: 'bold'}}>
                      🏆 View My Journey
                    </button>

                    {/* Feature: Academic Achievements */}
                    <button onClick={() => { openAchievements(); setDropdownOpen(false); }} style={{...menuBtnStyle, color: '#38A169', fontWeight: 'bold'}}>
                      🎓 Academic Achievements
                    </button>
                    
                    <div style={dividerStyle} />
                    <button onClick={() => { onLogout(); setDropdownOpen(false); }} style={{...menuBtnStyle, color: 'red'}}>Logout</button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </nav>

      {/* --- HERO SECTION --- */}
      <div style={heroSectionStyle}>
        <h1 style={heroTitleStyle}>Course Recommender</h1>
        <p style={{ fontSize: "1.2rem", marginBottom: "30px" }}>Discover the best courses for your skills and goals</p>
        
        <button onClick={() => navigate("/skill-gap")} style={skillGapBtnStyle}>
          Skill Gap Analysis
        </button>

        {/* RESTORED SEARCH FORM */}
        <form onSubmit={handleSearch} style={searchFormStyle}>
          <input 
            type="text" 
            placeholder="Search courses or skills..." 
            style={searchInputStyle} 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <button type="submit" style={searchSubmitBtnStyle}>Search</button>
        </form>
      </div>

      {/* --- MODAL: JOURNEY --- */}
      {isJourneyOpen && (
        <div style={modalOverlayStyle}>
          <div style={modalContentStyle}>
            <button onClick={() => setIsJourneyOpen(false)} style={closeBtnStyle}>✕</button>
            <h2 style={{ textAlign: 'center' }}>🏆 Your Journey</h2>
            <div style={modalGridStyle}>
              <div style={sectionBoxStyle}>
                <h4>Milestones</h4>
                <p>✅ Level 1: Profile Setup</p>
                <p style={{ color: '#aaa' }}>🔒 Level 2: Skill Assessment</p>
              </div>
              <div style={sectionBoxStyle}>
                <h4>Badges</h4>
                <div style={{ fontSize: '35px' }}>🚀 🧠</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- MODAL: ACADEMIC ACHIEVEMENTS --- */}
      {isAchievementsOpen && (
        <div style={modalOverlayStyle}>
          <div style={{...modalContentStyle, maxWidth: '750px'}}>
            <button onClick={() => setIsAchievementsOpen(false)} style={closeBtnStyle}>✕</button>
            <h2 style={{ borderBottom: '3px solid #38A169', paddingBottom: '10px' }}>🎓 Academic Achievements</h2>
            <div style={{ display: 'flex', gap: '20px', margin: '20px 0' }}>
               <div style={statBox}>🔥 Streak: {stats.streak} Days</div>
               <div style={statBox}>✅ Quizzes: {stats.quizzesPassed}</div>
            </div>
            <div style={tableContainer}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ textAlign: 'left', color: '#718096', fontSize: '13px' }}>
                    <th style={{paddingBottom: '10px'}}>Course Quiz</th>
                    <th>Score</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.history.length > 0 ? stats.history.map((h, i) => (
                    <tr key={i} style={{ borderTop: '1px solid #eee' }}>
                      <td style={{ padding: '12px 0' }}>{h.title}</td>
                      <td>{h.score}</td>
                      <td>{h.added_at ? new Date(h.added_at).toLocaleDateString() : 'N/A'}</td>
                    </tr>
                  )) : (
                    <tr><td colSpan="3" style={{textAlign:'center', padding:'20px'}}>No records found</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      <footer style={footerStyle}>
        <p>© 2026 Course Recommender Platform</p>
      </footer>
    </div>
  );
}

// --- STYLES (Merged from all versions) ---
const containerStyle = { minHeight: "100vh", display: "flex", flexDirection: "column", fontFamily: "Arial, sans-serif" };
const navbarStyle = { display: 'flex', justifyContent: 'space-between', padding: '10px 40px', backgroundColor: '#fff', borderBottom: '1px solid #eee', alignItems: 'center' };
const authBtnStyle = (bgColor) => ({ padding: "8px 16px", backgroundColor: bgColor, borderRadius: "4px", textDecoration: "none", color: "#fff", fontWeight: "bold", fontSize: "14px" });
const profileTriggerStyle = { display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', padding: '4px 8px', borderRadius: '4px', backgroundColor: '#f0faff' };
const avatarStyle = { width: '30px', height: '30px', borderRadius: '50%', backgroundColor: '#03a9f4', color: '#fff', display: 'flex', justifyContent: 'center', alignItems: 'center', fontWeight: 'bold' };
const dropdownCardStyle = { position: 'absolute', right: 0, top: '45px', width: '250px', backgroundColor: '#fff', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', borderRadius: '8px', zIndex: 100 };
const dividerStyle = { height: '1px', backgroundColor: '#eee', width: '100%' };
const knowMoreLink = { color: '#03a9f4', cursor: 'pointer', fontSize: '13px', fontWeight: 'bold' };
const menuBtnStyle = { width: '100%', padding: '12px 15px', textAlign: 'left', border: 'none', background: 'none', cursor: 'pointer', fontSize: '14px' };
const heroSectionStyle = { flex: 1, padding: "80px 20px", textAlign: "center", backgroundImage: 'linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url(https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1950&q=80)', backgroundSize: 'cover', color: "#fff" };
const heroTitleStyle = { fontSize: "3.5rem", color: "#ffeb3b", marginBottom: '10px' };
const skillGapBtnStyle = { padding: '12px 30px', backgroundColor: '#28a745', color: '#fff', border: 'none', borderRadius: '5px', cursor: 'pointer', fontWeight: 'bold', margin: '20px 0' };
const searchFormStyle = { display: "flex", width: "90%", maxWidth: "600px", margin: "20px auto" };
const searchInputStyle = { flex: 1, padding: "15px", borderRadius: "5px 0 0 5px", border: "none", outline: "none", fontSize: "1rem" };
const searchSubmitBtnStyle = { padding: "15px 30px", backgroundColor: "#ff6600", color: "#fff", border: "none", borderRadius: "0 5px 5px 0", cursor: "pointer", fontWeight: "bold" };
const modalOverlayStyle = { position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', backgroundColor: 'rgba(0,0,0,0.7)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 2000 };
const modalContentStyle = { backgroundColor: '#fff', padding: '30px', borderRadius: '15px', width: '90%', maxWidth: '600px', position: 'relative', color: '#333' };
const closeBtnStyle = { position: 'absolute', top: '15px', right: '15px', border: 'none', background: 'none', fontSize: '24px', cursor: 'pointer' };
const modalGridStyle = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginTop: '20px' };
const sectionBoxStyle = { padding: '15px', border: '1px solid #eee', borderRadius: '10px' };
const statBox = { flex: 1, padding: '15px', backgroundColor: '#F0FFF4', border: '1px solid #38A169', borderRadius: '10px', textAlign: 'center', fontWeight: 'bold', color: '#276749' };
const tableContainer = { marginTop: '20px', maxHeight: '300px', overflowY: 'auto' };
const footerStyle = { width: "100%", padding: "20px", textAlign: "center", backgroundColor: "rgba(0,0,0,0.8)", color: "#fff" };