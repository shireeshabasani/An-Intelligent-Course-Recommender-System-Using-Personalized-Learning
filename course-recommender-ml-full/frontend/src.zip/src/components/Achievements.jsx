/*import React, { useState, useEffect } from 'react';
import axios from 'axios';

const BACKEND_URL = 'http://localhost:8000';

const styles = {
    container: { padding: '20px', maxWidth: '1000px', margin: '0 auto', fontFamily: '"Segoe UI", Roboto, Helvetica, Arial, sans-serif' },
    header: { fontSize: '28px', fontWeight: 'bold', color: '#2D3748', borderBottom: '3px solid #38A169', paddingBottom: '12px', marginBottom: '30px' },
    topStats: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginBottom: '30px' },
    statCard: {
        backgroundColor: '#fff', borderRadius: '15px', border: '1px solid #e2e8f0',
        boxShadow: '0 4px 6px rgba(0,0,0,0.05)', padding: '20px', textAlign: 'center'
    },
    streakCount: { fontSize: '36px', fontWeight: 'bold', color: '#C05621', margin: '5px 0' },
    section: {
        backgroundColor: 'white', borderRadius: '15px', border: '1px solid #e2e8f0',
        boxShadow: '0 2px 10px rgba(0,0,0,0.05)', padding: '25px', marginBottom: '25px'
    },
    badgeGrid: { display: 'flex', flexWrap: 'wrap', gap: '15px', marginTop: '20px', justifyContent: 'center' },
    badgeItem: {
        display: 'flex', flexDirection: 'column', alignItems: 'center', width: '110px', 
        borderRadius: '12px', border: '1px solid #edf2f7', backgroundColor: '#f7fafc', padding: '15px', textAlign: 'center'
    },
    table: { width: '100%', borderCollapse: 'collapse', marginTop: '15px' },
    th: { textAlign: 'left', borderBottom: '2px solid #edf2f7', padding: '15px', color: '#4A5568', fontSize: '13px', fontWeight: 'bold', textTransform: 'uppercase' },
    td: { padding: '15px', borderBottom: '1px solid #f7fafc', fontSize: '14px', color: '#2D3748' },
    statusBadge: (passed) => ({
        padding: '6px 14px', borderRadius: '20px', fontSize: '11px', fontWeight: 'bold',
        backgroundColor: passed ? '#C6F6D5' : '#FED7D7', color: passed ? '#22543D' : '#822727',
        display: 'inline-block'
    })
};

const getBadgeParts = (name) => {
    const badgeMap = {
        'Daily Streak 3 🔥': { icon: '🔥', name: 'Hot Streak' },
        'Course Explorer 🗺️': { icon: '🗺️', name: 'Explorer' },
        'Skill Builder 🛠️': { icon: '🛠️', name: 'Builder' },
        'Quiz Master 🧠': { icon: '🧠', name: 'Master' },
    };
    return badgeMap[name] || { icon: '🏅', name: name };
};

const Achievements = ({ user }) => {
    const [streak, setStreak] = useState(0);
    const [badges, setBadges] = useState([]);
    const [quizResults, setQuizResults] = useState([]);
    const [loading, setLoading] = useState(true);

    const email = user?.email;

    useEffect(() => {
        const fetchData = async () => {
            if (!email) return;
            try {
                // Fetching all student data in parallel
                const [activityRes, badgesRes, quizRes] = await Promise.all([
                    axios.get(`${BACKEND_URL}/users/${encodeURIComponent(email)}/activity`),
                    axios.get(`${BACKEND_URL}/users/${encodeURIComponent(email)}/badges`),
                    axios.get(`${BACKEND_URL}/users/${encodeURIComponent(email)}/quiz-results`)
                ]);
                
                setStreak(activityRes.data.streak || 0);
                setBadges(badgesRes.data.badges || []);
                setQuizResults(quizRes.data || []);
            } catch (error) {
                console.error('Achievement Fetch Error:', error);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [email]);

    if (loading) return <div style={{...styles.container, textAlign: 'center', paddingTop: '100px'}}>Loading Transcript Data...</div>;

    // Calculate pass rate
    const passedCount = quizResults.filter(r => r.passed).length;

    return (
        <div style={styles.container}>
            <h1 style={styles.header}>🎓 Academic Achievements & Transcript</h1>
            
            <div style={styles.topStats}>
                <div style={styles.statCard}>
                    <p style={{fontSize: '12px', fontWeight: 'bold', color: '#718096'}}>CURRENT STREAK</p>
                    <p style={styles.streakCount}>{streak} Days</p>
                </div>
                <div style={styles.statCard}>
                    <p style={{fontSize: '12px', fontWeight: 'bold', color: '#718096'}}>QUIZZES PASSED</p>
                    <p style={{...styles.streakCount, color: '#2F855A'}}>{passedCount}</p>
                </div>
                <div style={styles.statCard}>
                    <p style={{fontSize: '12px', fontWeight: 'bold', color: '#718096'}}>BADGES EARNED</p>
                    <p style={{...styles.streakCount, color: '#2B6CB0'}}>{badges.length}</p>
                </div>
            </div>

           
            <div style={styles.section}>
                <h3 style={{margin: 0, color: '#2D3748', borderBottom: '1px solid #eee', paddingBottom: '10px'}}>Specializations Earned</h3>
                <div style={styles.badgeGrid}>
                    {badges.length > 0 ? badges.map((b, i) => {
                        const parts = getBadgeParts(b.name);
                        return (
                            <div key={i} style={styles.badgeItem} title={b.description}>
                                <span style={{fontSize:'40px', marginBottom: '8px'}}>{parts.icon}</span>
                                <span style={{fontSize:'11px', fontWeight: 'bold', color: '#4A5568'}}>{parts.name}</span>
                            </div>
                        );
                    }) : (
                        <p style={{color: '#A0AEC0', padding: '20px'}}>Score 80% or higher on a quiz level to earn badges!</p>
                    )}
                </div>
            </div>

            
            <div style={styles.section}>
                <h3 style={{margin: 0, color: '#2D3748', marginBottom: '15px'}}>Official Quiz Records</h3>
                <div style={{overflowX: 'auto'}}>
                    <table style={styles.table}>
                        <thead>
                            <tr>
                                <th style={styles.th}>Course & Level</th>
                                <th style={styles.th}>Result</th>
                                <th style={styles.th}>Status</th>
                                <th style={styles.th}>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {quizResults.length > 0 ? quizResults.map((r, i) => (
                                <tr key={i}>
                                    <td style={{...styles.td, fontWeight: 'bold'}}>
                                        {r.course_id.replace(/_/g, ' ').toUpperCase()} 
                                        <span style={{color: '#718096', fontSize: '12px', marginLeft: '10px'}}>
                                            (Quiz {r.quiz_number || 1})
                                        </span>
                                    </td>
                                    <td style={styles.td}>
                                        {r.score} / {r.total} 
                                        <span style={{color: '#718096', marginLeft: '5px'}}>({r.percentage}%)</span>
                                    </td>
                                    <td style={styles.td}>
                                        <div style={styles.statusBadge(r.passed)}>
                                            {r.passed ? "PASSED ✅" : "FAILED ⚠️"}
                                        </div>
                                    </td>
                                    <td style={styles.td}>
                                        {new Date(r.completed_at).toLocaleDateString()}
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan="4" style={{textAlign: 'center', padding: '40px', color: '#A0AEC0'}}>
                                        No quiz attempts found yet.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Achievements;*/
/*import React, { useState, useEffect } from 'react';
import axios from 'axios';

const BACKEND_URL = 'http://localhost:8000';

const styles = {
    container: { padding: '20px', maxWidth: '1000px', margin: '0 auto', fontFamily: '"Segoe UI", Roboto, Helvetica, Arial, sans-serif' },
    header: { fontSize: '28px', fontWeight: 'bold', color: '#2D3748', borderBottom: '3px solid #38A169', paddingBottom: '12px', marginBottom: '30px' },
    topStats: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginBottom: '30px' },
    statCard: {
        backgroundColor: '#fff', borderRadius: '15px', border: '1px solid #e2e8f0',
        boxShadow: '0 4px 6px rgba(0,0,0,0.05)', padding: '20px', textAlign: 'center'
    },
    streakCount: { fontSize: '36px', fontWeight: 'bold', color: '#C05621', margin: '5px 0' },
    section: {
        backgroundColor: 'white', borderRadius: '15px', border: '1px solid #e2e8f0',
        boxShadow: '0 2px 10px rgba(0,0,0,0.05)', padding: '25px', marginBottom: '25px'
    },
    badgeGrid: { display: 'flex', flexWrap: 'wrap', gap: '15px', marginTop: '20px', justifyContent: 'center' },
    badgeItem: {
        display: 'flex', flexDirection: 'column', alignItems: 'center', width: '110px', 
        borderRadius: '12px', border: '1px solid #edf2f7', backgroundColor: '#f7fafc', padding: '15px', textAlign: 'center'
    },
    table: { width: '100%', borderCollapse: 'collapse', marginTop: '15px' },
    th: { textAlign: 'left', borderBottom: '2px solid #edf2f7', padding: '15px', color: '#4A5568', fontSize: '13px', fontWeight: 'bold', textTransform: 'uppercase' },
    td: { padding: '15px', borderBottom: '1px solid #f7fafc', fontSize: '14px', color: '#2D3748' },
    statusBadge: (passed) => ({
        padding: '6px 14px', borderRadius: '20px', fontSize: '11px', fontWeight: 'bold',
        backgroundColor: passed ? '#C6F6D5' : '#FED7D7', color: passed ? '#22543D' : '#822727',
        display: 'inline-block'
    })
};

const getBadgeParts = (name) => {
    const badgeMap = {
        'Daily Streak 3 🔥': { icon: '🔥', name: 'Hot Streak' },
        'Course Explorer 🗺️': { icon: '🗺️', name: 'Explorer' },
        'Skill Builder 🛠️': { icon: '🛠️', name: 'Builder' },
        'Quiz Master 🧠': { icon: '🧠', name: 'Quiz Master' },
    };
    const match = Object.keys(badgeMap).find(key => name.includes(key) || key.includes(name));
    return badgeMap[match] || { icon: '🏅', name: name.replace(/[^\w\s]/gi, '') };
};

const Achievements = ({ user }) => {
    const [streak, setStreak] = useState(0);
    const [badges, setBadges] = useState([]);
    const [quizResults, setQuizResults] = useState([]);
    const [loading, setLoading] = useState(true);

    const email = user?.email;

    useEffect(() => {
        const fetchData = async () => {
            if (!email) return;
            setLoading(true);
            try {
                // Ensure these endpoints match your main.py routes
                const [activityRes, badgesRes, quizRes] = await Promise.all([
                    axios.get(`${BACKEND_URL}/users/${encodeURIComponent(email)}/activity?t=${Date.now()}`),
                    axios.get(`${BACKEND_URL}/users/${encodeURIComponent(email)}/badges?t=${Date.now()}`),
                    axios.get(`${BACKEND_URL}/users/${encodeURIComponent(email)}/quiz-results?t=${Date.now()}`)
                ]);
                
                setStreak(activityRes.data.streak || 0);
                setBadges(badgesRes.data.badges || []);
                setQuizResults(quizRes.data || []);
            } catch (error) {
                console.error('Achievement Fetch Error:', error);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [email]);

    if (loading) return <div style={{...styles.container, textAlign: 'center', paddingTop: '100px'}}>Loading Academic Records...</div>;

    // --- REQUIREMENT: 30% PASS THRESHOLD LOGIC ---
    const PASS_THRESHOLD = 30;
    const passedCount = quizResults.filter(r => (r.percentage || (r.score / r.total * 100)) >= PASS_THRESHOLD).length;

    return (
        <div style={styles.container}>
            <h1 style={styles.header}>🎓 Academic Achievements & Transcript</h1>
            
            <div style={styles.topStats}>
                <div style={styles.statCard}>
                    <p style={{fontSize: '12px', fontWeight: 'bold', color: '#718096'}}>CURRENT STREAK</p>
                    <p style={styles.streakCount}>{streak} Days</p>
                </div>
                <div style={styles.statCard}>
                    <p style={{fontSize: '12px', fontWeight: 'bold', color: '#718096'}}>LEVELS COMPLETED</p>
                    <p style={{...styles.streakCount, color: '#2F855A'}}>{passedCount}</p>
                </div>
                <div style={styles.statCard}>
                    <p style={{fontSize: '12px', fontWeight: 'bold', color: '#718096'}}>BADGES EARNED</p>
                    <p style={{...styles.streakCount, color: '#2B6CB0'}}>{badges.length}</p>
                </div>
            </div>

            <div style={styles.section}>
                <h3 style={{margin: 0, color: '#2D3748', borderBottom: '1px solid #eee', paddingBottom: '10px'}}>Specializations Earned</h3>
                <div style={styles.badgeGrid}>
                    {badges.length > 0 ? badges.map((b, i) => {
                        const parts = getBadgeParts(b.badge_name || b.name);
                        return (
                            <div key={i} style={styles.badgeItem} title={b.badge_name}>
                                <span style={{fontSize:'40px', marginBottom: '8px'}}>{parts.icon}</span>
                                <span style={{fontSize:'11px', fontWeight: 'bold', color: '#4A5568'}}>{parts.name}</span>
                            </div>
                        );
                    }) : (
                        <p style={{color: '#A0AEC0', padding: '20px'}}>Complete assessments with {PASS_THRESHOLD}%+ to earn badges!</p>
                    )}
                </div>
            </div>

            <div style={styles.section}>
                <h3 style={{margin: 0, color: '#2D3748', marginBottom: '15px'}}>Official Assessment Records</h3>
                <div style={{overflowX: 'auto'}}>
                    <table style={styles.table}>
                        <thead>
                            <tr>
                                <th style={styles.th}>Course & Module</th>
                                <th style={styles.th}>Performance</th>
                                <th style={styles.th}>Status</th>
                                <th style={styles.th}>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {quizResults.length > 0 ? quizResults.map((r, i) => {
                                // Dynamic Title Formatting
                                let friendlyName = r.course_title || r.course_id.toUpperCase().replace(/-/g, ' ');

                                // APPLYING 30% THRESHOLD HERE
                                const isPassed = (r.percentage || (r.score / r.total * 100)) >= PASS_THRESHOLD;

                                return (
                                    <tr key={i}>
                                        <td style={{...styles.td, fontWeight: 'bold'}}>
                                            {friendlyName} 
                                            <span style={{color: '#718096', fontSize: '12px', marginLeft: '10px'}}>
                                                (Quiz {r.quiz_number})
                                            </span>
                                        </td>
                                        <td style={styles.td}>
                                            {r.score} / {r.total} 
                                            <span style={{color: '#718096', marginLeft: '5px'}}>({r.percentage}%)</span>
                                        </td>
                                        <td style={styles.td}>
                                            <div style={styles.statusBadge(isPassed)}>
                                                {isPassed ? "PASSED ✅" : "RETAKE ⚠️"}
                                            </div>
                                        </td>
                                        <td style={styles.td}>
                                            {r.completed_at ? new Date(r.completed_at).toLocaleDateString() : "Recent"}
                                        </td>
                                    </tr>
                                );
                            }) : (
                                <tr>
                                    <td colSpan="4" style={{textAlign: 'center', padding: '40px', color: '#A0AEC0'}}>
                                        No assessment history available. Visit your Dashboard to begin.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Achievements;*/
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const BACKEND_URL = 'http://localhost:8000';

const Achievements = ({ user }) => {
    const [quizResults, setQuizResults] = useState([]);
    const [streak, setStreak] = useState(0);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!user?.email) return;
        const fetchData = async () => {
            try {
                const email = encodeURIComponent(user.email);
                const [actRes, quizRes] = await Promise.all([
                    axios.get(`${BACKEND_URL}/users/${email}/activity`),
                    axios.get(`${BACKEND_URL}/users/${email}/quiz-results`)
                ]);
                setStreak(actRes.data.streak || 0);
                setQuizResults(quizRes.data || []);
            } catch (err) {
                console.error("Fetch error", err);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [user]);

    if (loading) return <div style={{padding: '50px', textAlign: 'center'}}>Loading Academic Records...</div>;

    return (
        <div style={{ padding: '20px', maxWidth: '900px', margin: '0 auto', fontFamily: 'Segoe UI, sans-serif' }}>
            <h2 style={{borderBottom: '2px solid #38A169', paddingBottom: '10px'}}>🎓 Academic Achievements</h2>
            
            <div style={{ display: 'flex', gap: '20px', margin: '20px 0' }}>
                <div style={{padding: '15px', background: '#fff', borderRadius: '8px', boxShadow: '0 2px 5px rgba(0,0,0,0.1)', flex: 1}}>
                    <strong>🔥 Streak:</strong> {streak} Days
                </div>
                <div style={{padding: '15px', background: '#fff', borderRadius: '8px', boxShadow: '0 2px 5px rgba(0,0,0,0.1)', flex: 1}}>
                    <strong>✅ Quizzes:</strong> {quizResults.length}
                </div>
            </div>

            <table style={{ width: '100%', borderCollapse: 'collapse', background: 'white' }}>
                <thead>
                    <tr style={{ background: '#f8f9fa', borderBottom: '2px solid #eee' }}>
                        <th style={{ padding: '12px', textAlign: 'left' }}>Course</th>
                        <th style={{ padding: '12px', textAlign: 'left' }}>Quiz</th>
                        <th style={{ padding: '12px', textAlign: 'left' }}>Score</th>
                        <th style={{ padding: '12px', textAlign: 'left' }}>Status</th>
                        <th style={{ padding: '12px', textAlign: 'left' }}>Date</th>
                    </tr>
                </thead>
                // --- UPDATE THIS SECTION IN Achievements.js ---

<tbody>
    {quizResults.length > 0 ? quizResults.map((r, i) => {
        // We look for score/total, but use 0 as a fallback if they are missing
        const s = r.score ?? 0;
        const t = r.total ?? 0;
        const p = r.percentage ?? (t > 0 ? (s / t * 100) : 0);

        return (
            <tr key={i} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '12px' }}>
                    <strong>{r.course_title}</strong> <br/>
                    <small style={{color: '#666'}}>Quiz {r.quiz_number}</small>
                </td>
                <td style={{ padding: '12px', fontWeight: 'bold', color: '#2D3748' }}>
                    {s} / {t} 
                    <span style={{fontSize: '11px', color: '#718096', marginLeft: '5px'}}>
                        ({p.toFixed(0)}%)
                    </span>
                </td>
                <td style={{ padding: '12px' }}>
                    <span style={{ 
                        color: p >= 30 ? '#2F855A' : '#C53030', 
                        fontWeight: 'bold',
                        backgroundColor: p >= 30 ? '#F0FFF4' : '#FFF5F5',
                        padding: '4px 8px',
                        borderRadius: '4px'
                    }}>
                        {p >= 30 ? "PASSED" : "RETAKE"}
                    </span>
                </td>
                <td style={{ padding: '12px', color: '#718096' }}>
                    {r.completed_at ? new Date(r.completed_at).toLocaleDateString() : 'Today'}
                </td>
            </tr>
        );
    }) : (
        <tr><td colSpan="4" style={{textAlign: 'center', padding: '20px'}}>No records found</td></tr>
    )}
</tbody>
            </table>
        </div>
    );
};

export default Achievements;