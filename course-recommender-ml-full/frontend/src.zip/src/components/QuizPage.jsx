/*import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

const QuizPage = ({ user }) => {
  const { courseId, quizNum } = useParams(); // Added quizNum
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Corrected URL to match Backend: /quiz/{course_id}/{quiz_num}
    fetch(`http://localhost:8000/quiz/${courseId}/${quizNum}`)
      .then(res => {
        if (!res.ok) throw new Error("Quiz not found");
        return res.json();
      })
      .then(data => { setQuiz(data); setLoading(false); })
      .catch(err => { console.error(err); setLoading(false); });
  }, [courseId, quizNum]);

  const handleSubmit = async () => {
    // Map object answers {0: 1, 1: 0} to an array [-1, 1, 0...]
    const answersArray = quiz.questions.map((_, i) => answers[i] ?? -1);
    
    const response = await fetch("http://localhost:8000/quiz/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ 
        email: user.email, 
        course_id: courseId, 
        quiz_number: parseInt(quizNum), // Matches backend expected key
        answers: answersArray 
      })
    });
    const data = await response.json();
    setResult(data);
  };

  if (loading) return <div style={{textAlign: "center", padding: "50px"}}>Loading Quiz...</div>;
  if (!quiz) return <div style={{textAlign: "center", padding: "50px"}}>Quiz not found. Check your backend data.</div>;

  return (
    <div style={{ maxWidth: "800px", margin: "2rem auto", padding: "20px", fontFamily: "sans-serif" }}>
      {!result ? (
        <>
          <h2 style={{textTransform: "uppercase"}}>Level {quizNum}: {quiz.course_title || courseId}</h2>
          {quiz.questions.map((q, qIdx) => (
            <div key={qIdx} style={{ marginBottom: "20px", padding: "15px", border: "1px solid #eee", borderRadius: "8px" }}>
              <p><strong>{qIdx + 1}. {q.question}</strong></p>
              {q.options.map((opt, oIdx) => (
                <label key={oIdx} style={{ display: "block", margin: "5px 0", cursor: "pointer" }}>
                  <input 
                    type="radio" 
                    name={`q-${qIdx}`} 
                    checked={answers[qIdx] === oIdx}
                    onChange={() => setAnswers({ ...answers, [qIdx]: oIdx })} 
                  /> {opt}
                </label>
              ))}
            </div>
          ))}
          <button onClick={handleSubmit} style={{ padding: "10px 20px", backgroundColor: "#28a745", color: "white", border: "none", borderRadius: "5px", cursor: "pointer", width: "100%", fontSize: "16px" }}>
            Submit Quiz
          </button>
        </>
      ) : (
        <div>
          <h2 style={{ color: result.passed ? "#28a745" : "#dc3545" }}>{result.passed ? "✅ Passed!" : "⚠️ Level Completed"}</h2>
          <p>Final Score: {result.score} / {result.total} ({result.percentage}%)</p>
          <div style={{ marginTop: "30px" }}>
            <h3>Review:</h3>
            {result.details.map((item, idx) => (
              <div key={idx} style={{ padding: "10px", margin: "10px 0", borderLeft: `5px solid ${item.is_correct ? "#28a745" : "#dc3545"}`, backgroundColor: "#f9f9f9" }}>
                <p><strong>{item.question}</strong></p>
                <p style={{ color: item.is_correct ? "green" : "red" }}>Your Answer: {item.options[item.user_answer] || "Skipped"}</p>
                {!item.is_correct && <p style={{color: "blue"}}>Correct: {item.options[item.correct_answer]}</p>}
              </div>
            ))}
          </div>
          <button onClick={() => navigate("/dashboard")} style={{ marginTop: "20px", padding: "10px 20px", backgroundColor: "#007bff", color: "white", border: "none", borderRadius: "5px", width: "100%" }}>Return to Dashboard</button>
        </div>
      )}
    </div>
  );
};

export default QuizPage;*/
/*import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

const QuizPage = ({ user }) => {
  const { courseId, quizNum } = useParams();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);

  // 1. Initialize Page: Load Quiz and Check Completion Status
  useEffect(() => {
    const initQuiz = async () => {
      try {
        // Fetch the quiz questions
        const qRes = await fetch(`http://localhost:8000/quiz/${courseId}/${quizNum}`);
        const qData = await qRes.json();
        setQuiz(qData);

        // Check if this specific user has already completed this quiz
        const sRes = await fetch(`http://localhost:8000/quiz/status?email=${user.email}&course_id=${courseId}&quiz_num=${quizNum}`);
        if (sRes.ok) {
          const sData = await sRes.json();
          if (sData.completed) {
            // If completed, 'result' is populated with the answer key and previous score
            setResult(sData.previous_result);
          }
        }
      } catch (err) {
        console.error("Initialization error:", err);
      } finally {
        setLoading(false);
      }
    };
    initQuiz();
  }, [courseId, quizNum, user.email]);

  // 2. Handle Submission
  const handleSubmit = async () => {
    const answersArray = quiz.questions.map((_, i) => answers[i] ?? -1);
    try {
      const res = await fetch("http://localhost:8000/quiz/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          email: user.email, 
          course_id: courseId, 
          quiz_number: parseInt(quizNum), 
          answers: answersArray 
        })
      });
      const data = await res.json();
      setResult(data); // Switches page to Review Mode immediately
    } catch (err) {
      alert("Failed to submit. Please check your connection.");
    }
  };

  if (loading) return <div style={msgStyle}>Loading Assessment...</div>;
  if (!quiz) return <div style={{...msgStyle, color: "#E53E3E"}}>Quiz not found.</div>;

  return (
    <div style={{ maxWidth: "800px", margin: "2rem auto", padding: "20px", fontFamily: "'Segoe UI', Tahoma, sans-serif" }}>
   
      <div style={{ borderBottom: "3px solid #38A169", marginBottom: "30px", paddingBottom: "10px" }}>
        <h2 style={{ textTransform: "uppercase", color: "#2D3748", margin: 0 }}>
          Level {quizNum}: {quiz.course_title || courseId.replace(/-/g, ' ')}
        </h2>
      </div>


      {result && (
        <div style={{ 
          textAlign: "center", padding: "30px", marginBottom: "30px", borderRadius: "15px",
          backgroundColor: result.passed ? "#F0FFF4" : "#FFF5F5", 
          border: `2px solid ${result.passed ? "#38A169" : "#E53E3E"}` 
        }}>
          <h2 style={{ color: result.passed ? "#2F855A" : "#C53030", margin: 0 }}>
            {result.passed ? "🎉 Level Mastered!" : "⚠️ Review Required"}
          </h2>
          <div style={{ fontSize: "1.4rem", margin: "10px 0" }}>
            Score: <strong>{result.score} / {result.total}</strong>
          </div>
          <p style={{ color: "#4A5568", margin: 0 }}>Success Rate: {result.percentage}%</p>
        </div>
      )}

     
      {quiz.questions.map((q, idx) => {
        const review = result?.details?.[idx]; // Data containing correct vs user answer
        
        return (
          <div key={idx} style={questionBoxStyle}>
            <p style={{ fontSize: "1.1rem", fontWeight: "600", color: "#2D3748" }}>
              {idx + 1}. {q.question}
            </p>
            
            {q.options.map((opt, oIdx) => {
              // Determine if this option is selected (works for both live attempts and past results)
              const isSelected = result ? review?.user_answer === oIdx : answers[idx] === oIdx;
              const isCorrect = result ? review?.correct_answer === oIdx : false;

              // Color Logic for Review Mode
              let bgColor = "transparent";
              let borderColor = "#edf2f7";
              
              if (result) {
                if (isCorrect) {
                  bgColor = "#F0FFF4"; // Green for correct answer
                  borderColor = "#38A169";
                } else if (isSelected && !isCorrect) {
                  bgColor = "#FFF5F5"; // Red for wrong selection
                  borderColor = "#E53E3E";
                }
              } else if (isSelected) {
                bgColor = "#EBF8FF"; // Blue highlight while selecting
                borderColor = "#3182CE";
              }

              return (
                <label key={oIdx} style={{ ...optionLabelStyle, backgroundColor: bgColor, borderColor: borderColor }}>
                  <input 
                    type="radio" 
                    name={`q-${idx}`} 
                    disabled={!!result} // Lock radio buttons if already submitted/completed
                    style={{ marginRight: "12px", width: "18px", height: "18px" }}
                    checked={isSelected}
                    onChange={() => setAnswers({ ...answers, [idx]: oIdx })} 
                  /> 
                  <span style={{ color: "#4A5568", flex: 1 }}>{opt}</span>
                  
                
                  {result && isCorrect && <span style={tagStyle("#38A169")}>✅ Correct</span>}
                  {result && isSelected && !isCorrect && <span style={tagStyle("#E53E3E")}>❌ Your Choice</span>}
                </label>
              );
            })}
          </div>
        );
      })}

      
      {!result ? (
        <button onClick={handleSubmit} style={submitBtnStyle}>
          Submit Final Answers
        </button>
      ) : (
        <button onClick={() => navigate("/dashboard")} style={returnBtnStyle}>
          Return to Dashboard
        </button>
      )}
    </div>
  );
};

// --- STYLES ---
const msgStyle = { textAlign: "center", padding: "100px", fontSize: "1.2rem" };
const questionBoxStyle = { marginBottom: "20px", padding: "20px", backgroundColor: "#fff", border: "1px solid #e2e8f0", borderRadius: "12px", boxShadow: "0 2px 4px rgba(0,0,0,0.05)" };
const optionLabelStyle = { display: "flex", alignItems: "center", margin: "10px 0", cursor: "pointer", padding: "12px", borderRadius: "8px", border: "1px solid", transition: "0.2s ease" };
const tagStyle = (color) => ({ color: color, fontWeight: "bold", fontSize: "0.85rem", marginLeft: "10px" });
const submitBtnStyle = { padding: "15px", backgroundColor: "#38A169", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", width: "100%", fontWeight: "bold", fontSize: "1.1rem", boxShadow: "0 4px 6px rgba(56, 161, 105, 0.2)" };
const returnBtnStyle = { ...submitBtnStyle, backgroundColor: "#3182CE", marginTop: "20px" };

export default QuizPage;*/
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

const QuizPage = ({ user }) => {
  const { courseId, quizNum } = useParams();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);

  // 1. Initialize Page: Load Quiz and Check Completion Status
  useEffect(() => {
    // Critical: Handle cases where navigation might pass 'undefined' as a string
    if (!courseId || courseId === "undefined") {
      console.error("Course ID is missing or undefined.");
      setLoading(false);
      return;
    }

    const initQuiz = async () => {
      try {
        setLoading(true);
        // Fetch the quiz questions
        const qRes = await fetch(`http://localhost:8000/quiz/${courseId}/${quizNum}`);
        if (!qRes.ok) throw new Error("Quiz not found");
        const qData = await qRes.json();
        setQuiz(qData);

        // Check if this specific user has already completed this quiz (Persistence)
        const sRes = await fetch(`http://localhost:8000/quiz/status?email=${user.email}&course_id=${courseId}&quiz_num=${quizNum}`);
        if (sRes.ok) {
          const sData = await sRes.json();
          if (sData.completed) {
            // Populate 'result' to trigger Review Mode immediately
            setResult(sData.previous_result);
          }
        }
      } catch (err) {
        console.error("Initialization error:", err);
      } finally {
        setLoading(false);
      }
    };
    initQuiz();
  }, [courseId, quizNum, user.email, navigate]);

  // 2. Handle Submission
  const handleSubmit = async () => {
    // Construct answers array, defaulting to -1 for unanswered questions
    const answersArray = quiz.questions.map((_, i) => answers[i] ?? -1);
    
    try {
      const res = await fetch("http://localhost:8000/quiz/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          email: user.email, 
          course_id: courseId, 
          quiz_number: parseInt(quizNum), 
          answers: answersArray 
        })
      });

      if (!res.ok) throw new Error("Submission failed");
      
      const data = await res.json();
      // data contains: { score, total, percentage, passed, details: [...] }
      setResult(data); 
      window.scrollTo({ top: 0, behavior: 'smooth' }); // Scroll to top to see the score card
    } catch (err) {
      alert("Failed to submit. Please check your connection.");
    }
  };

  if (loading) return <div style={msgStyle}>Loading Assessment...</div>;
  if (!quiz) return (
    <div style={{...msgStyle, color: "#E53E3E"}}>
      <h3>Error: Quiz or Course ID not found.</h3>
      <button onClick={() => navigate("/dashboard")} style={{...returnBtnStyle, width: "auto", padding: "10px 20px"}}>
        Back to Dashboard
      </button>
    </div>
  );

  return (
    <div style={{ maxWidth: "800px", margin: "2rem auto", padding: "20px", fontFamily: "'Segoe UI', Tahoma, sans-serif" }}>
      
      {/* HEADER */}
      <div style={{ borderBottom: "3px solid #38A169", marginBottom: "30px", paddingBottom: "10px" }}>
        <h2 style={{ textTransform: "uppercase", color: "#2D3748", margin: 0 }}>
          Level {quizNum}: {quiz.course_title || courseId.replace(/-/g, ' ')}
        </h2>
      </div>

      {/* PERFORMANCE SUMMARY (Visible only in Review Mode) */}
      {result && (
        <div style={{ 
          textAlign: "center", padding: "30px", marginBottom: "30px", borderRadius: "15px",
          backgroundColor: result.passed ? "#F0FFF4" : "#FFF5F5", 
          border: `2px solid ${result.passed ? "#38A169" : "#E53E3E"}`,
          boxShadow: "0 4px 12px rgba(0,0,0,0.05)"
        }}>
          <h2 style={{ color: result.passed ? "#2F855A" : "#C53030", margin: 0 }}>
            {result.passed ? "🎉 Level Mastered!" : "⚠️ Review Required"}
          </h2>
          <div style={{ fontSize: "1.8rem", margin: "15px 0", color: "#2D3748" }}>
            Score: <strong>{result.score} / {result.total}</strong>
          </div>
          <p style={{ fontSize: "1.1rem", color: "#4A5568", margin: 0 }}>
            Success Rate: <strong>{result.percentage}%</strong> 
            {result.passed ? " (Pass)" : " (Fail - 80% Required)"}
          </p>
        </div>
      )}

      {/* QUESTIONS LIST */}
      {quiz.questions.map((q, idx) => {
        // 'review' contains user_answer, correct_answer, and is_correct for this specific question
        const review = result?.details?.[idx]; 
        
        return (
          <div key={idx} style={questionBoxStyle}>
            <p style={{ fontSize: "1.1rem", fontWeight: "600", color: "#2D3748" }}>
              {idx + 1}. {q.question}
            </p>
            
            {q.options.map((opt, oIdx) => {
              // Check if this option was the one chosen by the user
              const isSelected = result ? review?.user_answer === oIdx : answers[idx] === oIdx;
              // Check if this option is the correct answer
              const isCorrect = result ? review?.correct_answer === oIdx : false;

              // STYLING LOGIC
              let bgColor = "transparent";
              let borderColor = "#edf2f7";
              
              if (result) {
                if (isCorrect) {
                  bgColor = "#F0FFF4"; // Always highlight the correct answer in green
                  borderColor = "#38A169";
                } else if (isSelected && !isCorrect) {
                  bgColor = "#FFF5F5"; // Highlight user's wrong choice in red
                  borderColor = "#E53E3E";
                }
              } else if (isSelected) {
                bgColor = "#EBF8FF"; // Blue highlight while the quiz is active
                borderColor = "#3182CE";
              }

              return (
                <label key={oIdx} style={{ ...optionLabelStyle, backgroundColor: bgColor, borderColor: borderColor }}>
                  <input 
                    type="radio" 
                    name={`q-${idx}`} 
                    disabled={!!result} // Disable changes in Review Mode
                    style={{ marginRight: "12px", width: "18px", height: "18px" }}
                    checked={isSelected}
                    onChange={() => setAnswers({ ...answers, [idx]: oIdx })} 
                  /> 
                  <span style={{ color: "#4A5568", flex: 1 }}>{opt}</span>
                  
                  {/* FEEDBACK TAGS */}
                  {result && isCorrect && <span style={tagStyle("#38A169")}>✅ Correct</span>}
                  {result && isSelected && !isCorrect && <span style={tagStyle("#E53E3E")}>❌ Your Choice</span>}
                </label>
              );
            })}
          </div>
        );
      })}

      {/* FOOTER ACTIONS */}
      <div style={{ marginTop: "40px" }}>
        {!result ? (
          <button onClick={handleSubmit} style={submitBtnStyle}>
            Submit Final Answers
          </button>
        ) : (
          <button onClick={() => navigate("/dashboard")} style={returnBtnStyle}>
            Return to Dashboard
          </button>
        )}
      </div>
    </div>
  );
};

// --- STYLES ---
const msgStyle = { textAlign: "center", padding: "100px", fontSize: "1.2rem", fontFamily: "sans-serif" };
const questionBoxStyle = { marginBottom: "20px", padding: "20px", backgroundColor: "#fff", border: "1px solid #e2e8f0", borderRadius: "12px", boxShadow: "0 2px 4px rgba(0,0,0,0.05)" };
const optionLabelStyle = { display: "flex", alignItems: "center", margin: "10px 0", cursor: "pointer", padding: "12px", borderRadius: "8px", border: "1px solid", transition: "0.2s ease" };
const tagStyle = (color) => ({ color: color, fontWeight: "bold", fontSize: "0.85rem", marginLeft: "10px" });
const submitBtnStyle = { padding: "15px", backgroundColor: "#38A169", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", width: "100%", fontWeight: "bold", fontSize: "1.1rem", boxShadow: "0 4px 6px rgba(56, 161, 105, 0.2)" };
const returnBtnStyle = { ...submitBtnStyle, backgroundColor: "#3182CE" };

export default QuizPage;