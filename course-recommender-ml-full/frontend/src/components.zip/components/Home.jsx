
/*import React, { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Home({ user, onLogout }) {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Example featured courses, replace or fetch real data as needed
  const featuredCourses = [
    {
      title: "Machine Learning Foundations",
      provider: "Coursera",
      url: "https://coursera.org/learn/machine-learning",
      description: "Intro ML, supervised/unsupervised, basics of models.",
      duration: "55 hours"
    },
    {
      title: "Frontend Web Development Bootcamp",
      provider: "Udemy",
      url: "https://udemy.com/course/frontend-web-development",
      description: "HTML, CSS, JavaScript, React, project-based learning.",
      duration: "40 hours"
    },
    {
      title: "Data Science with Python",
      provider: "edX",
      url: "https://edx.org/course/data-science-python",
      description: "Pandas/Numpy, data cleaning, analysis, real-world datasets.",
      duration: "65 hours"
    }
  ];

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim() !== "") {
      navigate(`/search-results?q=${encodeURIComponent(query)}`);
    }
  };

  // Close dropdown if clicked outside
  useEffect(() => {
    function handleClickOutside(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const backgroundImage =
    "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1950&q=80";

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        display: "flex",
        flexDirection: "column",
        color: "#fff",
        fontFamily: "Arial, sans-serif",
      }}
    >
    
      <div
        style={{
          width: "100%",
          display: "flex",
          justifyContent: "flex-end",
          padding: "20px 50px",
          gap: "15px",
          backgroundColor: "rgba(0,0,0,0.6)",
          position: "relative",
        }}
      >
        {!user && (
          <>
            <Link
              to="/login"
              style={{
                padding: "10px 20px",
                backgroundColor: "#007bff",
                borderRadius: "5px",
                textDecoration: "none",
                color: "#fff",
                fontWeight: "bold",
                transition: "0.3s",
              }}
              onMouseOver={(e) => (e.target.style.backgroundColor = "#0056b3")}
              onMouseOut={(e) => (e.target.style.backgroundColor = "#007bff")}
            >
              Login
            </Link>
            <Link
              to="/register"
              style={{
                padding: "10px 20px",
                backgroundColor: "#28a745",
                borderRadius: "5px",
                textDecoration: "none",
                color: "#fff",
                fontWeight: "bold",
                transition: "0.3s",
              }}
              onMouseOver={(e) => (e.target.style.backgroundColor = "#1c7430")}
              onMouseOut={(e) => (e.target.style.backgroundColor = "#28a745")}
            >
              Register
            </Link>
          </>
        )}
        {user && (
          <div style={{ position: "relative" }} ref={dropdownRef}>
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              style={{
                background: "none",
                border: "none",
                cursor: "pointer",
                fontWeight: "bold",
                fontSize: "16px",
                padding: "10px",
                color: "#fff",
              }}
            >
              {user.name || user.email}
            </button>
            {dropdownOpen && (
              <div
                style={{
                  position: "absolute",
                  right: 0,
                  top: "100%",
                  backgroundColor: "white",
                  color: "black",
                  boxShadow: "0 2px 5px rgba(0,0,0,0.15)",
                  borderRadius: "5px",
                  marginTop: "5px",
                  zIndex: 10,
                  width: "170px",
                }}
              >
                <button
                  onClick={() => { navigate("/dashboard"); setDropdownOpen(false); }}
                  style={{
                    display: "block",
                    width: "100%",
                    padding: "10px",
                    textAlign: "left",
                    border: "none",
                    background: "none",
                    cursor: "pointer",
                  }}
                >
                  Dashboard
                </button>
                <button
                  onClick={() => { navigate("/skill-gap"); setDropdownOpen(false); }}
                  style={{
                    display: "block",
                    width: "100%",
                    padding: "10px",
                    textAlign: "left",
                    border: "none",
                    background: "none",
                    cursor: "pointer",
                  }}
                >
                  Skill Gap Analysis
                </button>
                <button
                  onClick={() => {
                    onLogout();
                    setDropdownOpen(false);
                  }}
                  style={{
                    display: "block",
                    width: "100%",
                    padding: "10px",
                    textAlign: "left",
                    border: "none",
                    background: "none",
                    cursor: "pointer",
                    color: "red",
                  }}
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      
      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          textAlign: "center",
          gap: "20px",
          backdropFilter: "brightness(0.85)",
          padding: "50px 20px",
        }}
      >
        <h1
          style={{
            fontSize: "4rem",
            color: "#ffeb3b",
            textShadow: "2px 2px 8px rgba(0,0,0,0.7)",
          }}
        >
          Course Recommender
        </h1>
        <p
          style={{
            fontSize: "1.5rem",
            color: "#fff",
            textShadow: "1px 1px 5px rgba(0,0,0,0.6)",
          }}
        >
          Discover the best courses for your skills and goals
        </p>

        <button
          onClick={() => navigate("/skill-gap")}
          style={{
            margin: "15px 0 10px 0",
            padding: "14px 35px",
            backgroundColor: "#28a745",
            color: "white",
            fontSize: "1.2rem",
            border: "none",
            borderRadius: "8px",
            fontWeight: "bold",
            cursor: "pointer",
            letterSpacing: "0.2px",
            boxShadow: "0 1px 6px rgba(40,167,69,0.21)"
          }}
        >
          Skill Gap Analysis
        </button>

        <form onSubmit={handleSearch} style={{ display: "flex", width: "60%", maxWidth: "700px" }}>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search courses or skills..."
            style={{
              flex: 1,
              padding: "15px 20px",
              fontSize: "1.1rem",
              borderRadius: "10px 0 0 10px",
              border: "none",
              outline: "none",
            }}
          />
          <button
            type="submit"
            style={{
              padding: "15px 30px",
              border: "none",
              backgroundColor: "#ff6600",
              color: "#fff",
              fontSize: "1.1rem",
              borderRadius: "0 10px 10px 0",
              cursor: "pointer",
              fontWeight: "bold",
            }}
          >
            Search
          </button>
        </form>

    
        <div style={{ marginTop: "36px", display: "flex", gap: "30px", flexWrap: "wrap", justifyContent: "center" }}>
          {featuredCourses.map((course, idx) => (
            <div key={idx} style={{
              backgroundColor: "white",
              color: "#222",
              borderRadius: "12px",
              boxShadow: "0 2px 12px rgba(0,0,0,0.09)",
              minWidth: 265,
              maxWidth: 300,
              padding: "1.5rem",
              marginBottom: "15px",
              textAlign: "left"
            }}>
              <h3 style={{ color: "#007bff", fontSize: "1.2rem", marginBottom: 8 }}>{course.title}</h3>
              <div style={{ fontSize: 14, color: "#555" }}><b>Provider:</b> {course.provider}</div>
              <p style={{ marginTop: 10, fontSize: "1rem", minHeight: "56px" }}>{course.description}</p>
              <p style={{ fontSize: 13, color: "#666" }}><b>Duration:</b> {course.duration}</p>
              <a
                href={course.url}
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: "#007bff", fontWeight: "bold", textDecoration: "none" }}
              >
                View Course
              </a>
            </div>
          ))}
        </div>
      </div>

      
      <div
        style={{
          width: "100%",
          padding: "20px",
          textAlign: "center",
          backgroundColor: "rgba(0,0,0,0.6)",
          color: "#fff",
        }}
      >
        <p>© 2025 Course Recommender Platform</p>
      </div>
    </div>
  );
}*/



import React, { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

// IMPORTANT: Define the backend URL
const BACKEND_URL = 'http://localhost:8000'; 

export default function Home({ user, onLogout }) {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  const [displayName, setDisplayName] = useState(user ? user.name || user.email : ""); // New state for display name

  // Fetch the user's full profile (including name) if only email is present
  useEffect(() => {
    if (user && user.email && !user.name) {
      // Assuming your backend has an endpoint like /users/:email that returns {name: '...', email: '...'}
      fetch(`${BACKEND_URL}/users/${user.email}`)
        .then(res => res.json())
        .then(data => {
          if (data.name) {
            setDisplayName(data.name);
            // Optionally, update the user state in App.jsx if you can access the setUser function here
            // Since we can't, we'll just use the local state for display.
          }
        })
        .catch(error => console.error("Failed to fetch user name:", error));
    } else if (user && user.name) {
        setDisplayName(user.name);
    }
  }, [user]); // Re-run when the user object changes

  // Example featured courses, replace or fetch real data as needed
  const featuredCourses = [
    {
      title: "Machine Learning Foundations",
      provider: "Coursera",
      url: "https://coursera.org/learn/machine-learning",
      description: "Intro ML, supervised/unsupervised, basics of models.",
      duration: "55 hours"
    },
    {
      title: "Frontend Web Development Bootcamp",
      provider: "Udemy",
      url: "https://udemy.com/course/frontend-web-development",
      description: "HTML, CSS, JavaScript, React, project-based learning.",
      duration: "40 hours"
    },
    {
      title: "Data Science with Python",
      provider: "edX",
      url: "https://edx.org/course/data-science-python",
      description: "Pandas/Numpy, data cleaning, analysis, real-world datasets.",
      duration: "65 hours"
    }
  ];

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim() !== "") {
      navigate(`/search-results?q=${encodeURIComponent(query)}`);
    }
  };

  // Close dropdown if clicked outside
  useEffect(() => {
    function handleClickOutside(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const backgroundImage =
    "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1950&q=80";

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        display: "flex",
        flexDirection: "column",
        color: "#fff",
        fontFamily: "Arial, sans-serif",
      }}
    >
      {/* Header with user info */}
      <div
        style={{
          width: "100%",
          display: "flex",
          justifyContent: "flex-end",
          padding: "20px 50px",
          gap: "15px",
          backgroundColor: "rgba(0,0,0,0.6)",
          position: "relative",
        }}
      >
        {!user && (
          <>
            <Link
              to="/login"
              style={{
                padding: "10px 20px",
                backgroundColor: "#007bff",
                borderRadius: "5px",
                textDecoration: "none",
                color: "#fff",
                fontWeight: "bold",
                transition: "0.3s",
              }}
              onMouseOver={(e) => (e.target.style.backgroundColor = "#0056b3")}
              onMouseOut={(e) => (e.target.style.backgroundColor = "#007bff")}
            >
              Login
            </Link>
            <Link
              to="/register"
              style={{
                padding: "10px 20px",
                backgroundColor: "#28a745",
                borderRadius: "5px",
                textDecoration: "none",
                color: "#fff",
                fontWeight: "bold",
                transition: "0.3s",
              }}
              onMouseOver={(e) => (e.target.style.backgroundColor = "#1c7430")}
              onMouseOut={(e) => (e.target.style.backgroundColor = "#28a745")}
            >
              Register
            </Link>
          </>
        )}
        {user && (
          <div style={{ position: "relative" }} ref={dropdownRef}>
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              style={{
                background: "none",
                border: "none",
                cursor: "pointer",
                fontWeight: "bold",
                fontSize: "16px",
                padding: "10px",
                color: "#fff",
              }}
            >
              {/* NOW USES THE DISPLAY NAME STATE */}
              {displayName} 
            </button>
            {dropdownOpen && (
              <div
                style={{
                  position: "absolute",
                  right: 0,
                  top: "100%",
                  backgroundColor: "white",
                  color: "black",
                  boxShadow: "0 2px 5px rgba(0,0,0,0.15)",
                  borderRadius: "5px",
                  marginTop: "5px",
                  zIndex: 10,
                  width: "170px",
                }}
              >
                <button
                  onClick={() => { navigate("/dashboard"); setDropdownOpen(false); }}
                  style={{
                    display: "block",
                    width: "100%",
                    padding: "10px",
                    textAlign: "left",
                    border: "none",
                    background: "none",
                    cursor: "pointer",
                  }}
                >
                  Dashboard
                </button>
                <button
                  onClick={() => { navigate("/skill-gap"); setDropdownOpen(false); }}
                  style={{
                    display: "block",
                    width: "100%",
                    padding: "10px",
                    textAlign: "left",
                    border: "none",
                    background: "none",
                    cursor: "pointer",
                  }}
                >
                  Skill Gap Analysis
                </button>
                <button
                  onClick={() => { navigate("/achievements"); setDropdownOpen(false); }}
                  style={{
                    display: "block",
                    width: "100%",
                    padding: "10px",
                    textAlign: "left",
                    border: "none",
                    background: "none",
                    cursor: "pointer",
                  }}
                >
                  🏆 Achievements
                </button>
                <button
                  onClick={() => {
                    onLogout();
                    setDropdownOpen(false);
                  }}
                  style={{
                    display: "block",
                    width: "100%",
                    padding: "10px",
                    textAlign: "left",
                    border: "none",
                    background: "none",
                    cursor: "pointer",
                    color: "red",
                  }}
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Main Content */}
      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          textAlign: "center",
          gap: "20px",
          backdropFilter: "brightness(0.85)",
          padding: "50px 20px",
        }}
      >
        <h1
          style={{
            fontSize: "4rem",
            color: "#ffeb3b",
            textShadow: "2px 2px 8px rgba(0,0,0,0.7)",
          }}
        >
          Course Recommender
        </h1>
        <p
          style={{
            fontSize: "1.5rem",
            color: "#fff",
            textShadow: "1px 1px 5px rgba(0,0,0,0.6)",
          }}
        >
          Discover the best courses for your skills and goals
        </p>

        {/* Skill Gap Analysis Page Button */}
        <button
          onClick={() => navigate("/skill-gap")}
          style={{
            margin: "15px 0 10px 0",
            padding: "14px 35px",
            backgroundColor: "#28a745",
            color: "white",
            fontSize: "1.2rem",
            border: "none",
            borderRadius: "8px",
            fontWeight: "bold",
            cursor: "pointer",
            letterSpacing: "0.2px",
            boxShadow: "0 1px 6px rgba(40,167,69,0.21)"
          }}
        >
          Skill Gap Analysis
        </button>

        {/* Search Bar */}
        <form onSubmit={handleSearch} style={{ display: "flex", width: "60%", maxWidth: "700px" }}>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search courses or skills..."
            style={{
              flex: 1,
              padding: "15px 20px",
              fontSize: "1.1rem",
              borderRadius: "10px 0 0 10px",
              border: "none",
              outline: "none",
            }}
          />
          <button
            type="submit"
            style={{
              padding: "15px 30px",
              border: "none",
              backgroundColor: "#ff6600",
              color: "#fff",
              fontSize: "1.1rem",
              borderRadius: "0 10px 10px 0",
              cursor: "pointer",
              fontWeight: "bold",
            }}
          >
            Search
          </button>
        </form>

        {/* Featured Courses */}
        <div style={{ marginTop: "36px", display: "flex", gap: "30px", flexWrap: "wrap", justifyContent: "center" }}>
          {featuredCourses.map((course, idx) => (
            <div key={idx} style={{
              backgroundColor: "white",
              color: "#222",
              borderRadius: "12px",
              boxShadow: "0 2px 12px rgba(0,0,0,0.09)",
              minWidth: 265,
              maxWidth: 300,
              padding: "1.5rem",
              marginBottom: "15px",
              textAlign: "left"
            }}>
              <h3 style={{ color: "#007bff", fontSize: "1.2rem", marginBottom: 8 }}>{course.title}</h3>
              <div style={{ fontSize: 14, color: "#555" }}><b>Provider:</b> {course.provider}</div>
              <p style={{ marginTop: 10, fontSize: "1rem", minHeight: "56px" }}>{course.description}</p>
              <p style={{ fontSize: 13, color: "#666" }}><b>Duration:</b> {course.duration}</p>
              <a
                href={course.url}
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: "#007bff", fontWeight: "bold", textDecoration: "none" }}
              >
                View Course
              </a>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div
        style={{
          width: "100%",
          padding: "20px",
          textAlign: "center",
          backgroundColor: "rgba(0,0,0,0.6)",
          color: "#fff",
        }}
      >
        <p>© 2025 Course Recommender Platform</p>
      </div>
    </div>
  );
}