
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const allSkills = [
  "python", "html", "css", "javascript", "react", "nodejs", "java",
  "sql", "machine learning", "deep learning", "docker", "kubernetes",
  "aws", "gcp", "azure", "cloud computing", "api", "restful api",
  "devops", "ci/cd", "database", "mongodb", "oracle", "postgresql",
  "frontend", "backend", "django", "spring", "vue", "angular",
  "pandas", "numpy", "data visualization", "data analysis", "networking",
  "security", "penetration testing", "cryptography", "flutter", "android",
  "ios", "react native", "ui/ux", "figma", "adobe xd", "c++", "unity",
  "unreal", "blockchain", "solidity", "iot", "microservices", "api design",
  "scrum", "selenium", "manual testing", "automation testing"
];

const roles = [
  "Data Scientist",
  "Web Developer",
  "ML Engineer",
  "DevOps Engineer",
  "Cloud Architect",
  "Frontend Developer",
  "Backend Developer",
  "Database Administrator",
  "AI Engineer",
  "Cybersecurity Analyst",
  "Mobile App Developer",
  "Full Stack Developer",
  "Big Data Engineer",
  "UI/UX Designer",
  "Blockchain Engineer",
  "IoT Solutions Architect",
  "Product Manager",
  "QA Engineer",
  "Network Engineer",
  "Game Developer"
];

const SkillGapPage = ({ email }) => {
  const [userSkills, setUserSkills] = useState([]);
  const [skillsInput, setSkillsInput] = useState("");
  const [filteredSkills, setFilteredSkills] = useState([]);
  const [skillsLoading, setSkillsLoading] = useState(true);
  const [skillsSaved, setSkillsSaved] = useState(false);

  const [role, setRole] = useState('');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch user skills from backend (initial only)
  useEffect(() => {
    async function fetchUserSkills() {
      setSkillsLoading(true);
      try {
        const res = await axios.get(`http://127.0.0.1:8000/users/${encodeURIComponent(email)}`);
        const skills = res.data.skills ? Object.keys(res.data.skills) : [];
        if (skills.length > 0) {
          setUserSkills(skills);
          setSkillsSaved(true);
        }
      } catch {
        setUserSkills([]);
        setSkillsSaved(false);
      } finally {
        setSkillsLoading(false);
      }
    }
    fetchUserSkills();
  }, [email]);

  // Filter suggestions for input bar
  useEffect(() => {
    const q = skillsInput.toLowerCase().trim();
    setFilteredSkills(q 
      ? allSkills.filter(s => s.toLowerCase().startsWith(q) && !userSkills.includes(s))
      : []);
  }, [skillsInput, userSkills]);

  // Add skill
  const addSkill = (skill) => {
    if (!userSkills.includes(skill)) {
      setUserSkills([...userSkills, skill]);
    }
    setSkillsInput('');
    setFilteredSkills([]);
  };

  // Remove skill chip
  const removeSkill = (skill) => {
    setUserSkills(userSkills.filter(s => s !== skill));
  };

  // Save to backend, then move to gap UI
  const saveSkills = async () => {
    let finalSkills = userSkills;
    if (skillsInput.trim() && !finalSkills.includes(skillsInput.trim())) {
      finalSkills = [...finalSkills, skillsInput.trim()];
      setUserSkills(finalSkills);
      setSkillsInput('');
    }
    if (!finalSkills.length) {
      alert("Please add at least one skill");
      return;
    }
    try {
      await axios.put(`http://127.0.0.1:8000/users/${encodeURIComponent(email)}/skills`, finalSkills);
      setError(null);
      setSkillsSaved(true);
    } catch {
      alert("Failed to save skills");
    }
  };

  // Skill gap
  const fetchSkillGap = async () => {
    if (!role) return;
    setLoading(true);
    try {
      const res = await axios.get(
        `http://127.0.0.1:8000/users/${encodeURIComponent(email)}/skill-gap`,
        { params: { role } }
      );
      setData(res.data);
      setError(null);
    } catch {
      setError("Failed to fetch skill gap");
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  if (skillsLoading) return <div>Loading your skills...</div>;

  // Phase ONE: tag/chip input mode
  if (!skillsSaved) {
    return (
      <div style={{ maxWidth: 600, margin: '3rem auto', padding: 24, backgroundColor: '#fff', borderRadius: 8, textAlign: 'center' }}>
        <h3>Tell us your current skills!</h3>
        <p>Type a skill and press Enter or pick from suggestions. Click x to remove a skill. When finished, click "Save Skills".</p>
        <div style={{ position: 'relative' }}>
          <input
            type="text"
            value={skillsInput}
            onChange={e => setSkillsInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter' && skillsInput.trim()) {
                e.preventDefault();
                addSkill(skillsInput.trim());
              }
            }}
            placeholder="Start typing a skill..."
            style={{ width: '100%', padding: 10, marginBottom: 0 }}
          />
          {filteredSkills.length > 0 && (
            <ul style={{
              position: 'absolute',
              width: '100%',
              maxHeight: 150,
              overflowY: 'auto',
              backgroundColor: 'white',
              border: '1px solid #ccc',
              margin: 0,
              padding: 0,
              listStyle: 'none',
              zIndex: 100
            }}>
              {filteredSkills.map(skill => (
                <li key={skill}
                    onClick={() => addSkill(skill)}
                    style={{ padding: 10, cursor: 'pointer' }}>
                  {skill}
                </li>
              ))}
            </ul>
          )}
        </div>

        <div style={{ marginTop: 15, display: 'flex', flexWrap: 'wrap', gap: 10, justifyContent: 'center' }}>
          {userSkills.map(skill => (
            <div key={skill} style={{
              backgroundColor: '#007BFF', color: 'white', borderRadius: 20, padding: '5px 12px', display: 'flex', alignItems: 'center', gap: 8
            }}>
              <span>{skill}</span>
              <button onClick={() => removeSkill(skill)} style={{
                background: 'transparent', border: 'none', color: 'white', cursor: 'pointer', fontWeight: 'bold', fontSize: 16, lineHeight: 1, padding: 0
              }}>×</button>
            </div>
          ))}
        </div>

        <button onClick={saveSkills} style={{
          marginTop: 25,
          padding: '10px 30px',
          backgroundColor: '#28a745',
          border: 'none',
          color: '#fff',
          fontWeight: 'bold',
          fontSize: 16,
          borderRadius: 8,
          cursor: 'pointer'
        }}>
          Save Skills
        </button>
      </div>
    );
  }

  // Phase TWO: gap analysis
  return (
    <div style={{ maxWidth: 700, margin: '3rem auto', padding: 24, backgroundColor:'#f0f0f0', borderRadius: 8, textAlign: 'center' }}>
      <h2>Skill Gap Analysis</h2>
      <p>
        <strong>Your Saved Skills:</strong> {userSkills.join(', ')}
        <button onClick={() => { setSkillsSaved(false); setData(null); }} style={{ marginLeft: 15, cursor: 'pointer', fontSize: 13 }}>Edit Skills</button>
      </p>
      <select value={role} onChange={e => setRole(e.target.value)} style={{ width: '100%', padding: 12, fontSize: 16 }}>
        <option value="">Select Role</option>
        {roles.map(r => <option key={r} value={r}>{r}</option>)}
      </select>
      <button onClick={fetchSkillGap} disabled={!role || loading} style={{
        marginTop: 20,
        padding: '12px 0',
        width: '100%',
        fontWeight: 'bold',
        fontSize: 16,
        backgroundColor: (!role || loading) ? '#ccc' : '#007bff',
        color: 'white',
        border: 'none',
        borderRadius: 8,
        cursor: (!role || loading) ? 'not-allowed' : 'pointer'
      }}>
        {loading ? "Checking..." : "Check Gaps"}
      </button>

      {error && <p style={{ color: 'red', marginTop: 16 }}>{error}</p>}

      {data && (
        <div style={{ marginTop: 24, textAlign: 'left' }}>
          <h3>Role: {role}</h3>
          <p><b>Required Skills:</b> {data.required_skills.join(', ')}</p>
          <p><b>Your Skills matching role:</b> {data.existing_skills.join(', ') || 'None'}</p>
          <p><b>Missing Skills:</b> {data.missing_skills.join(', ') || 'None'}</p>
          {data.recommended_courses.length > 0 && (
            <>
              <h4>Recommended Courses</h4>
              <ul>
                {data.recommended_courses.map(({ skill, course_title, url }) => (
                  <li key={skill}><a href={url} target="_blank" rel="noopener noreferrer">{course_title}</a> (skill: {skill})</li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default SkillGapPage;
