/*import React, { useState, useEffect } from 'react';

// VERIFY THIS IS CORRECT
const BACKEND_URL = 'http://localhost:8000'; 

// --- Core Badge Definitions (Inspired by Coursera, LeetCode, Udemy, etc.) ---
const BADGE_DEFINITIONS = {
    // 1. Consistency / Streak Badges (LeetCode / Duolingo Style)
    "Daily Streak 3 🔥": { icon: "🔥", name: "3-Day Streak", description: "Maintained a learning streak for 3 days." },
    "Daily Streak 7 🚀": { icon: "🚀", name: "7-Day Streak", description: "Kept a study momentum for a full week." },
    "Daily Streak 30 ⭐": { icon: "⭐", name: "30-Day Committer", description: "Committed to learning for a month straight!" },
    "Daily Streak 100 👑": { icon: "👑", name: "Century Learner", description: "Mastered the habit of learning for 100 days." },

    // 2. Mastery / Completion Badges (Udemy / Coursera Certificate Style)
    "Course Explorer 🗺️": { icon: "🗺️", name: "First Course Complete", description: "Completed your very first course." },
    "Skill Builder 🛠️": { icon: "🛠️", name: "Skill Builder", description: "Successfully finished a full learning path or specialization." },
    "Project Master 💡": { icon: "💡", name: "Project Master", description: "Completed a hands-on course project." },
    "Certification Ready 📄": { icon: "📄", name: "Certification Ready", description: "Scored 90%+ on a final course assessment." },

    // 3. Depth / Specialization Badges (Infosys Springboard Style)
    "Deep Dive 🏊": { icon: "🏊", name: "Deep Dive", description: "Spent over 20 hours studying one specific skill." },
    "Tech Specialist 💻": { icon: "💻", name: "Tech Specialist", description: "Completed 3 related courses in a single technology (e.g., Python)." },
    "Foundations Tier I 🧱": { icon: "🧱", name: "Foundations Tier I", description: "Finished the introductory courses in 5 different domains." },
    
    // 4. Exploration / Community Badges (Byjus / Platform Engagement)
    "First Search 🔍": { icon: "🔍", name: "First Search", description: "Used the course search feature for the first time." },
    "Community Helper 💬": { icon: "💬", name: "Community Helper", description: "Posted a helpful answer in a course discussion forum." },
    "Goal Setter 📈": { icon: "📈", name: "Goal Setter", description: "Set your first personalized learning goal." },
};

// --- Helper Functions ---

const getBadgeDetails = (badgeName) => {
    return BADGE_DEFINITIONS[badgeName] || { 
        icon: "🏅", 
        name: badgeName.replace(/[^a-zA-Z\s]/g, '').trim() || badgeName, 
        description: "A recognition award." 
    };
};

// --- Styles for the Achievements Page ---
const styles = {
    container: {
        padding: '20px',
        maxWidth: '900px',
        margin: '0 auto',
        fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
        backgroundColor: '#f5f7fa',
        minHeight: '100vh',
    },
    header: {
        fontSize: '28px',
        fontWeight: '700',
        color: '#1a1a1a', 
        borderBottom: '3px solid #38A169', 
        paddingBottom: '10px',
        marginBottom: '40px',
        textAlign: 'center',
    },
    // Streak Card - Focus
    streakCard: {
        backgroundColor: '#ffffff',
        borderRadius: '12px',
        border: '1px solid #e0e0e0',
        boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
        padding: '25px',
        marginBottom: '40px',
        textAlign: 'center',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    streakIcon: { fontSize: '48px', marginBottom: '10px' },
    streakCount: { fontSize: '48px', fontWeight: 'bold', color: '#FF9900', margin: '0' },
    streakLabel: { fontSize: '18px', color: '#555', marginTop: '5px' },

    // Badges Section
    achievementsSection: {
        backgroundColor: '#ffffff',
        borderRadius: '12px',
        border: '1px solid #e0e0e0',
        boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
        padding: '25px',
    },
    badgesHeader: {
        fontSize: '22px',
        fontWeight: '600',
        margin: '0 0 20px 0',
        color: '#1a1a1a',
        borderBottom: '1px solid #eee',
        paddingBottom: '10px',
    },
    badgeGrid: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
        gap: '20px',
        padding: '10px 0',
    },
    badgeItem: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '15px',
        border: '1px solid #ddd',
        borderRadius: '8px',
        transition: 'all 0.3s ease',
        cursor: 'help', 
        backgroundColor: '#f9f9f9',
        height: '100%', // Ensure consistent height for all grid items
    },
    badgeItemHover: { 
        transform: 'translateY(-3px)',
        boxShadow: '0 6px 15px rgba(0,0,0,0.1)',
        borderColor: '#38A169',
    },
    badgeIcon: {
        fontSize: '36px',
        marginBottom: '8px',
    },
    badgeName: {
        fontSize: '14px',
        fontWeight: '600',
        textAlign: 'center',
        color: '#333',
    },
    badgeLocked: { // Style for a badge not yet earned
        filter: 'grayscale(100%) opacity(50%)',
        backgroundColor: '#efefef',
        borderStyle: 'dashed',
        borderColor: '#ccc',
    },
    noBadges: {
        margin: 20,
        fontSize: '16px',
        color: '#777',
        textAlign: 'center',
        gridColumn: '1 / -1',
    }
};

const Achievements = ({ email }) => {
    const [streak, setStreak] = useState(0);
    const [earnedBadges, setEarnedBadges] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [hoveredBadgeIndex, setHoveredBadgeIndex] = useState(null);

    useEffect(() => {
        const fetchAchievements = async () => {
            if (!email) { setLoading(false); return; }

            try {
                // Fetch Streak
                const activityResponse = await fetch(`${BACKEND_URL}/users/${email}/activity`);
                if (!activityResponse.ok) throw new Error("Failed to fetch activity.");
                const activityData = await activityResponse.json();
                setStreak(activityData.streak);

                // Fetch Badges
                const badgesResponse = await fetch(`${BACKEND_URL}/users/${email}/badges`);
                if (!badgesResponse.ok) throw new Error("Failed to fetch badges.");
                const badgesData = await badgesResponse.json();
                // We only store the badge names for quick lookup
                setEarnedBadges(badgesData.badges.map(b => b.name)); 
            
            } catch (err) {
                console.error("Error fetching achievements:", err);
                setError("Could not load achievements. Please ensure the backend is running.");
            } finally {
                setLoading(false);
            }
        };

        fetchAchievements();
    }, [email]);


    if (loading) return <div style={styles.container}><p style={{ textAlign: 'center' }}>Loading achievements...</p></div>;
    if (error) return <div style={styles.container}><p style={{ textAlign: 'center', color: 'red' }}>Error: {error}</p></div>;
    
    
    // Logic to determine the active Streak Badge for display in the Streak Card
    const getActiveStreakBadge = (currentStreak) => {
        if (currentStreak >= 100) return getBadgeDetails("Daily Streak 100 👑");
        if (currentStreak >= 30) return getBadgeDetails("Daily Streak 30 ⭐");
        if (currentStreak >= 7) return getBadgeDetails("Daily Streak 7 🚀");
        if (currentStreak >= 3) return getBadgeDetails("Daily Streak 3 🔥");
        return null;
    };

    const activeStreakBadge = getActiveStreakBadge(streak);

    // Prepare all badges for display
    const allBadgeNames = Object.keys(BADGE_DEFINITIONS);
    const badgeDataForDisplay = allBadgeNames.map(name => {
        const isEarned = earnedBadges.includes(name);
        return {
            ...getBadgeDetails(name),
            name: name,
            isEarned: isEarned,
            awardedAt: isEarned ? new Date().toLocaleDateString() : null
        };
    });


    return (
        <div style={styles.container}>
            <h1 style={styles.header}>🏆 Your Learning Achievements</h1>

            <div style={styles.streakCard}>
                <div style={styles.streakIcon}>
                    {activeStreakBadge ? activeStreakBadge.icon : '🔥'}
                </div>
                <h3 style={{ margin: '0 0 10px 0', fontSize: '20px', color: '#1a1a1a' }}>
                    {activeStreakBadge ? activeStreakBadge.name : 'Daily Study Streak'}
                </h3>
                <p style={styles.streakCount}>{streak} {streak === 1 ? 'Day' : 'Days'}</p>
                <p style={styles.streakLabel}>
                    {activeStreakBadge ? activeStreakBadge.description : 'Log in daily to keep your streak alive!'}
                </p>
            </div>

          
            <div style={styles.achievementsSection}>
                <h2 style={styles.badgesHeader}>All Badges: Earned ({earnedBadges.length}) & Goals</h2>
                <div style={styles.badgeGrid}>
                    {badgeDataForDisplay.map((badge, index) => {
                        const isHovered = index === hoveredBadgeIndex;
                        const badgeDetails = getBadgeDetails(badge.name);

                        // Determine the visual style (Locked/Earned)
                        let itemStyle = styles.badgeItem;
                        if (!badge.isEarned) {
                            itemStyle = { ...itemStyle, ...styles.badgeLocked };
                        }
                        if (isHovered && badge.isEarned) {
                            itemStyle = { ...itemStyle, ...styles.badgeItemHover };
                        }
                        
                        // Set the tooltip title
                        const titleText = badge.isEarned 
                            ? `${badgeDetails.name} - Earned: ${badge.awardedAt || 'Today'}\nDescription: ${badgeDetails.description}` 
                            : `${badgeDetails.name} - LOCKED\nGoal: ${badgeDetails.description}`;

                        return (
                            <div
                                key={index}
                                title={titleText}
                                style={itemStyle}
                                onMouseEnter={() => setHoveredBadgeIndex(index)}
                                onMouseLeave={() => setHoveredBadgeIndex(null)}
                            >
                                <span style={{ ...styles.badgeIcon }}>
                                    {badgeDetails.icon}
                                </span>
                                <span style={styles.badgeName}>
                                    {badgeDetails.name}
                                </span>
                                {!badge.isEarned && (
                                    <span style={{ fontSize: '10px', color: '#888', marginTop: '5px' }}>LOCKED</span>
                                )}
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};

export default Achievements;
*/



import React, { useState, useEffect } from 'react';
import axios from 'axios'; // <-- NEW IMPORT

const BACKEND_URL = 'http://localhost:8000'; // VERIFY THIS IS CORRECT

// --- Styles for the Achievements Page ---
const styles = {
    container: { padding: '20px', maxWidth: '800px', margin: '0 auto', fontFamily: 'Arial, sans-serif' },
    header: { fontSize: '24px', fontWeight: 'bold', color: '#38A169', borderBottom: '2px solid #38A169', paddingBottom: '10px', marginBottom: '30px' },
    
    streakCard: {
        backgroundColor: 'white', 
        borderRadius: '8px', 
        border: '1px solid #e0e0e0',
        boxShadow: '0 2px 5px rgba(0,0,0,0.05)', 
        padding: '20px', 
        marginBottom: '30px',
        textAlign: 'center',
    },
    streakCount: { fontSize: '36px', fontWeight: 'bold', color: '#FF9900', margin: '10px 0' },
    streakLabel: { fontSize: '16px', color: '#555' },

    // NEW STYLE FOR MARK PROGRESS BUTTON
    markButton: {
        padding:'10px 18px',
        backgroundColor:'#28a745',
        color:'white', 
        border:'none',
        borderRadius:'5px',
        cursor:'pointer',
        fontWeight: 'bold',
        marginTop: '15px',
        transition: 'background-color 0.2s',
    },
    
    achievementsSection: {
        backgroundColor: 'white',
        borderRadius: '8px',
        border: '1px solid #e0e0e0',
        boxShadow: '0 2px 5px rgba(0,0,0,0.05)',
        padding: '20px',
    },
    badgeGrid: { 
        display: 'flex', 
        flexWrap: 'wrap', 
        gap: '20px',
        marginTop: '20px',
        justifyContent: 'center',
    },
    badgeItem: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        width: '80px',
        height: '80px',
        borderRadius: '10px',
        border: '1px solid #ccc',
        backgroundColor: '#f9f9f9',
        padding: '10px',
        cursor: 'help',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
        transition: 'transform 0.2s',
    },
    badgeIcon: { fontSize: '36px', lineHeight: '1', marginBottom: '5px' },
    badgeName: { fontSize: '10px', fontWeight: 'bold', textAlign: 'center', lineHeight: '1.2', color: '#333' }
};

// Helper function to map badge names from the database to their icon and display name
const getBadgeParts = (name) => {
    
    // Mapping of all achievement badges to their icons
    // Using DB-style names observed in your MongoDB Compass (e.g., 'Daily Streak 3')
    const badgeMap = {
        // --- STREAK BADGES ---
        'Daily Streak 1': { icon: '🟢', name: 'The Starter' },
        'Daily Streak 2': { icon: '👯', name: 'Double Tap' },
        'Daily Streak 3': { icon: '🔥', name: 'First Light' }, // Matches icon seen in screenshot
        'Daily Streak 7': { icon: '✅', name: 'Consistent Learner' },
        'Daily Streak 14': { icon: '🚀', name: 'Momentum Master' },
        'Daily Streak 30': { icon: '🗓️', name: 'Month of Mastery' },
        'Daily Streak 50': { icon: '🧱', name: 'The Habit Builder' },
        'Daily Streak 100': { icon: '💯', name: 'Quarter Century' },
        'Daily Streak 180': { icon: '⭐', name: 'Six Star Striker' },

        // --- PROJECT BADGES ---
        'Course Explorer': { icon: '🗺️', name: 'Course Explorer' }, // Name seen in DB screenshot
        'Skill Builder': { icon: '🛠️', name: 'Skill Builder' }, // Name seen in DB screenshot
        'Data Wrangler': { icon: '🧹', name: 'Data Wrangler' },
        'Algorithm Architect': { icon: '⚙️', name: 'Algorithm Architect' },
        'Model Evaluator': { icon: '📊', name: 'Model Evaluator' },
        'System Deployer': { icon: '🚢', name: 'System Deployer' },
        'Full Stack Recommender': { icon: '👑', name: 'Full Stack Recommender' },
        'Vector Space Expert': { icon: '📐', name: 'Vector Space Expert' },
        'Pandas Power User': { icon: '🐼', name: 'Pandas Power User' },
        'API Artisan': { icon: '🔌', name: 'API Artisan' },
        'Personalization Pioneer': { icon: '👤', name: 'Personalization Pioneer' },
    };

    const mappedBadge = badgeMap[name];
    if (mappedBadge) {
        return mappedBadge;
    }

    // Fallback for any other badge not explicitly mapped
    return { icon: '🏅', name: name };
};


const Achievements = ({ email }) => {
    const [streak, setStreak] = useState(0);
    const [badges, setBadges] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchAchievementsData = async () => {
        if (!email) return;

        try {
            // Hitting /activity triggers badge checks and returns the streak
            const activityPromise = fetch(`${BACKEND_URL}/users/${email}/activity`).then(res => res.json());
            // Hitting /badges returns the list of awarded badges
            const badgesPromise = fetch(`${BACKEND_URL}/users/${email}/badges`).then(res => res.json());

            const [activityData, badgesData] = await Promise.all([activityPromise, badgesPromise]);

            setStreak(activityData.streak);
            setBadges(badgesData.badges);

        } catch (error) {
            console.error('Error fetching achievements data:', error);
        } finally {
            setLoading(false);
        }
    };

    const markProgress = async () => {
        const today = new Date().toISOString().slice(0, 10);
        try {
            // Assuming your backend expects a POST request to this endpoint
            // to log user activity and update the streak/badges
            await axios.post(`${BACKEND_URL}/track/event`, {
                email: email,
                date: today
            });
            alert("Marked today's progress! Streak updated.");
            // Re-fetch data to update the displayed streak and earned badges
            await fetchAchievementsData(); 
        } catch (error) {
            // Display a more informative error message
            const errorMessage = error.response && error.response.data && error.response.data.message 
                                ? error.response.data.message 
                                : "Failed to mark progress. Check backend logs.";
            alert(errorMessage);
        }
    };

    useEffect(() => {
        fetchAchievementsData();
    }, [email]);

    if (loading) {
        return <div style={styles.container}>Loading Achievements...</div>;
    }

    return (
        <div style={styles.container}>
            <h1 style={styles.header}>🏆 My Achievements for {email}</h1>
            
            {/* STREAK CARD (Now includes the button) */}
            <div style={styles.streakCard}>
                <p style={styles.streakLabel}>Current Daily Learning Streak</p>
                <p style={styles.streakCount}>{streak} days</p>
                <p style={styles.streakLabel}>Keep up the momentum!</p>
                <button 
                    onClick={markProgress} 
                    style={styles.markButton}
                    onMouseOver={(e) => e.target.style.backgroundColor = '#1e8e3e'}
                    onMouseOut={(e) => e.target.style.backgroundColor = '#28a745'}
                >
                    Mark Today as Completed
                </button>
            </div>

            {/* BADGES SECTION */}
            <div style={styles.achievementsSection}>
                <h2 style={{fontSize: '20px', margin: '0 0 15px 0', borderBottom: '1px solid #eee', paddingBottom: '10px'}}>Earned Badges ({badges.length})</h2>
                <div style={styles.badgeGrid}>
                    {badges.length > 0 ? (
                        badges.map((badge, index) => {
                            const { icon, name } = getBadgeParts(badge.name);
                            return (
                                <div 
                                    key={index} 
                                    style={styles.badgeItem} 
                                    title={`${badge.name} - Awarded: ${new Date(badge.awarded_at).toLocaleDateString()}.\nDescription: ${badge.description}`}
                                >
                                    <span style={styles.badgeIcon}>{icon}</span>
                                    <span style={styles.badgeName}>{name}</span>
                                </div>
                            );
                        })
                    ) : (
                        <p style={{ margin: 20, fontSize: '14px', color: '#777' }}>No badges yet. Maintain a streak or add a course to start earning!</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Achievements;