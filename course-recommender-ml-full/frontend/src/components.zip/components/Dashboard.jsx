

/*import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const SkillGapPanel = ({ email, goal }) => {
  const [gapData, setGapData] = useState({ missing_skills: [], recommended_courses: [] });

  useEffect(() => {
    if (!email || !goal) return;
    axios.get(`http://127.0.0.1:8000/users/${encodeURIComponent(email)}/skill-gap`, { params: { goal } })
      .then(res => setGapData(res.data))
      .catch(() => setGapData({ missing_skills: [], recommended_courses: [] }));
  }, [email, goal]);

 
};

const Dashboard = ({ user }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [learningPath, setLearningPath] = useState([]);
  const [streak, setStreak] = useState(0);
  const [personalizedPath, setPersonalizedPath] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchActivity() {
      if (!user) return;
      try {
        const res = await axios.get(`http://127.0.0.1:8000/users/${encodeURIComponent(user.email)}/activity`);
        setStreak(res.data.streak);
        setLearningPath(res.data.learning_path);
      } catch {
        setStreak(0);
        setLearningPath([]);
      }
    }
    fetchActivity();
  }, [user]);

  const handleSearch = async () => {
    if (!query) return;
    const res = await axios.get(`http://127.0.0.1:8000/search?q=${query}`);
    const mappedResults = res.data.results.map(course => ({
      ...course,
      id: course.id || course._id
    }));
    setResults(mappedResults);
    console.log("Search results:", mappedResults);
  };

  const handleShowPersonalizedPath = async (course) => {
    try {
      const res = await axios.get('http://127.0.0.1:8000/path-for-course', {
        params: { course_id: course.id, email: user.email }
      });
      setPersonalizedPath(res.data.personalized_path);
    } catch {
      alert("Unable to fetch personalized path");
    }
  };

  const handleSelectCourse = async (course) => {
    console.log("COURSE OBJECT:", course);
    try {
      const response = await axios.post(
        `http://127.0.0.1:8000/users/${encodeURIComponent(user.email)}/add-course`,
        {
          course_id: course.id,
          title: course.title,
          hours: course.duration_hours || 1,
          url: course.url,
        }
      );
      alert(`Course added! Estimated days: ${response.data.course.days_to_complete}`);
      setLearningPath((prev) => [...prev, response.data.course]);
    } catch (err) {
      alert("Failed to add course");
      console.error(err);
    }
  };

  const markProgress = async () => {
    const today = new Date().toISOString().slice(0, 10);
    try {
      await axios.post('http://127.0.0.1:8000/track/event', {
        email: user.email,
        date: today
      });
      alert("Marked today's progress! Streak updated.");
      const res = await axios.get(`http://127.0.0.1:8000/users/${encodeURIComponent(user.email)}/activity`);
      setStreak(res.data.streak);
    } catch {
      alert("Failed to mark progress.");
    }
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif', backgroundColor: '#f5f7fa', minHeight: '100vh' }}>
      <h1>Welcome {user.email}</h1>

      <section style={{padding:'1rem',backgroundColor:'white',borderRadius:'10px', boxShadow:'0 4px 8px rgba(0,0,0,0.1)', maxWidth:'350px', marginBottom:'2rem'}}>
        <h3>Streaks Maintained</h3>
        <p style={{fontSize:'2rem',fontWeight:'bold'}}>{streak} days</p>
        <button onClick={markProgress} style={{padding:'8px 12px',backgroundColor:'#28a745',color:'white', border:'none',borderRadius:'5px',cursor:'pointer'}}>
          Mark Today as Completed
        </button>
      </section>

      <SkillGapPanel email={user.email} goal="data scientist" />

      <section style={{padding:'1.5rem',backgroundColor:'white',borderRadius:'15px', boxShadow:'0 4px 12px rgba(0,0,0,0.07)', maxWidth:'680px', marginBottom:'2rem'}}>
        <h3 style={{ color: "#28a745", marginBottom: '1rem' }}>Your Personalized Learning Path</h3>
        {learningPath && learningPath.length > 0 ? (
          <div style={{display:'flex', flexDirection:'column', gap:'18px'}}>
            {learningPath.map((course, idx) => (
              <div key={idx} style={{border:'1px solid #e0e0e0', borderRadius:14, background:'#fcfcfc', padding:18, boxShadow:'0 1px 4px rgba(40,167,69,0.09)'}}>
                <div style={{fontWeight:500, fontSize:17, marginBottom:7}}>{course.title}</div>
                <div style={{fontSize:14, color:'#666', marginBottom:10}}>
                  Total Duration: <strong>{course.days_to_complete}</strong> days to complete
                </div>
                {course.provider && (
                  <div style={{fontSize:12,color:'#444',marginBottom:10}}>
                    Provider: {course.provider}
                  </div>
                )}
                <div style={{marginLeft:10}}>
                  <strong>Roadmap:</strong>
                  <ul>
                    {(course.roadmap || []).map((module, modIdx) => (
                      <li key={modIdx} style={{fontSize:13, marginBottom:4}}>
                        {module.module} &mdash; {module.days_to_complete} day(s) ({module.hours} hours)
                      </li>
                    ))}
                  </ul>
                </div>
                <a href={course.url} target="_blank" rel="noopener noreferrer" style={{fontSize:13,color:'#007bff', textDecoration:'none', fontWeight:600, letterSpacing:0.2, marginTop:8, display:'inline-block'}}>
                  Go to Course
                </a>
              </div>
            ))}
          </div>
        ) : <span>No courses selected yet.</span>}
      </section>

      <section>
        <h2 style={{ marginBottom: '0.5rem' }}>Search for Courses</h2>
        <div style={{ display: 'flex', maxWidth: '600px', marginBottom: '1rem' }}>
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search courses..."
            style={{ flex: 1, padding: '10px', borderRadius: '4px 0 0 4px', border: '1px solid #ccc' }}
          />
          <button
            onClick={handleSearch}
            style={{ padding: '10px 20px', borderRadius: '0 4px 4px 0', border: 'none', backgroundColor: '#007bff', color: 'white', cursor: 'pointer' }}
          >
            Search
          </button>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '15px' }}>
          {results.map(course => (
            <div
              key={course.id}
              style={{
                border: '1px solid #ddd',
                borderRadius: 8,
                padding: 15,
                margin: 5,
                backgroundColor: '#fff',
                boxShadow: '0 1px 5px rgba(0,0,0,0.1)',
                width: 'calc(33% - 20px)',
                cursor: 'pointer'
              }}
              onClick={() => handleShowPersonalizedPath(course)}
              title="Click to view personalized path"
            >
              <h4 style={{margin:'0 0 10px'}}>{course.title}</h4>
              <div style={{ fontSize: '0.9em', color: '#666' }}>Provider: {course.provider}</div>
              <div style={{ fontSize: '0.85em', color: '#999' }}>Duration: {course.duration_hours} hours</div>
              <button
                onClick={(e) => { e.stopPropagation(); handleSelectCourse(course); }}
                style={{ marginTop: 10, padding: '6px 12px', backgroundColor: '#007bff', border: 'none', color: 'white', borderRadius: 5, cursor: 'pointer' }}
              >
                Add to Learning Path
              </button>
            </div>
          ))}
        </div>
      </section>
      {personalizedPath.length > 0 && (
        <section style={{marginTop: '2rem', background: '#f6fff9', borderRadius: 12, padding: 18, boxShadow: '0 1px 8px rgba(40,167,69,0.05)'}}>
          <h3 style={{color: "#007bff"}}>Personalized Path for Selected Course</h3>
          {personalizedPath.map((c, idx) => (
            <div key={idx} style={{margin:'16px 0',padding:'12px',background:idx===0?'#e8f5fd':'#fff',borderRadius:8,boxShadow:'0 1px 3px rgba(0,0,0,0.06)'}}>
              <b>{c.title}</b> {" "}<span style={{color: "#888"}}>({c.provider})</span>
              <div>Duration: {c.duration_hours} hours | Days to complete: <b>{c.days_to_complete}</b></div>
              <div>Similarity Score: {c.similarity}</div>
              <a href={c.url} target="_blank" rel="noopener noreferrer" style={{color: "#007bff"}}>Go to Course</a>
            </div>
          ))}
        </section>
      )}
    </div>
  );
};

export default Dashboard;
*/

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const SkillGapPanel = ({ email, goal }) => {
  const [gapData, setGapData] = useState({ missing_skills: [], recommended_courses: [] });

  useEffect(() => {
    if (!email || !goal) return;
    axios.get(`http://127.0.0.1:8000/users/${encodeURIComponent(email)}/skill-gap`, { params: { goal } })
      .then(res => setGapData(res.data))
      .catch(() => setGapData({ missing_skills: [], recommended_courses: [] }));
  }, [email, goal]);
};

const Dashboard = ({ user }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [learningPath, setLearningPath] = useState([]);
  const [streak, setStreak] = useState(0); // Kept state, but no longer displayed/modified here
  const [personalizedPath, setPersonalizedPath] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchActivity() {
      if (!user) return;
      try {
        const res = await axios.get(`http://127.0.0.1:8000/users/${encodeURIComponent(user.email)}/activity`);
        setStreak(res.data.streak); // Keeping this for now, as fetching path is tied to it
        setLearningPath(res.data.learning_path);
      } catch {
        setStreak(0);
        setLearningPath([]);
      }
    }
    fetchActivity();
  }, [user]);

  const handleSearch = async () => {
    if (!query) return;
    const res = await axios.get(`http://127.000.1:8000/search?q=${query}`);
    const mappedResults = res.data.results.map(course => ({
      ...course,
      id: course.id || course._id
    }));
    setResults(mappedResults);
    console.log("Search results:", mappedResults);
  };

  const handleShowPersonalizedPath = async (course) => {
    try {
      const res = await axios.get('http://127.0.0.1:8000/path-for-course', {
        params: { course_id: course.id, email: user.email }
      });
      setPersonalizedPath(res.data.personalized_path);
    } catch {
      alert("Unable to fetch personalized path");
    }
  };

  const handleSelectCourse = async (course) => {
    console.log("COURSE OBJECT:", course);
    try {
      const response = await axios.post(
        `http://127.0.0.1:8000/users/${encodeURIComponent(user.email)}/add-course`,
        {
          course_id: course.id,
          title: course.title,
          hours: course.duration_hours || 1,
          url: course.url,
        }
      );
      alert(`Course added! Estimated days: ${response.data.course.days_to_complete}`);
      setLearningPath((prev) => [...prev, response.data.course]);
    } catch (err) {
      alert("Failed to add course");
      console.error(err);
    }
  };

  // REMOVED markProgress function

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif', backgroundColor: '#f5f7fa', minHeight: '100vh' }}>
      <h1>Welcome {user.email}</h1>

      {/* STREAK CARD REMOVED FROM HERE */}
      {/* The SkillGapPanel is still here, though currently commented out in the original file */}
      <SkillGapPanel email={user.email} goal="data scientist" /> 

      <section style={{padding:'1.5rem',backgroundColor:'white',borderRadius:'15px', boxShadow:'0 4px 12px rgba(0,0,0,0.07)', maxWidth:'680px', marginBottom:'2rem'}}>
        <h3 style={{ color: "#28a745", marginBottom: '1rem' }}>Your Personalized Learning Path</h3>
        {learningPath && learningPath.length > 0 ? (
          <div style={{display:'flex', flexDirection:'column', gap:'18px'}}>
            {learningPath.map((course, idx) => (
              <div key={idx} style={{border:'1px solid #e0e0e0', borderRadius:14, background:'#fcfcfc', padding:18, boxShadow:'0 1px 4px rgba(40,167,69,0.09)'}}>
                <div style={{fontWeight:500, fontSize:17, marginBottom:7}}>{course.title}</div>
                <div style={{fontSize:14, color:'#666', marginBottom:10}}>
                  Total Duration: <strong>{course.days_to_complete}</strong> days to complete
                </div>
                {course.provider && (
                  <div style={{fontSize:12,color:'#444',marginBottom:10}}>
                    Provider: {course.provider}
                  </div>
                )}
                <div style={{marginLeft:10}}>
                  <strong>Roadmap:</strong>
                  <ul>
                    {(course.roadmap || []).map((module, modIdx) => (
                      <li key={modIdx} style={{fontSize:13, marginBottom:4}}>
                        {module.module} &mdash; {module.days_to_complete} day(s) ({module.hours} hours)
                      </li>
                    ))}
                  </ul>
                </div>
                <a href={course.url} target="_blank" rel="noopener noreferrer" style={{fontSize:13,color:'#007bff', textDecoration:'none', fontWeight:600, letterSpacing:0.2, marginTop:8, display:'inline-block'}}>
                  Go to Course
                </a>
              </div>
            ))}
          </div>
        ) : <span>No courses selected yet.</span>}
      </section>

      <section>
        <h2 style={{ marginBottom: '0.5rem' }}>Search for Courses</h2>
        <div style={{ display: 'flex', maxWidth: '600px', marginBottom: '1rem' }}>
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search courses..."
            style={{ flex: 1, padding: '10px', borderRadius: '4px 0 0 4px', border: '1px solid #ccc' }}
          />
          <button
            onClick={handleSearch}
            style={{ padding: '10px 20px', borderRadius: '0 4px 4px 0', border: 'none', backgroundColor: '#007bff', color: 'white', cursor: 'pointer' }}
          >
            Search
          </button>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '15px' }}>
          {results.map(course => (
            <div
              key={course.id}
              style={{
                border: '1px solid #ddd',
                borderRadius: 8,
                padding: 15,
                margin: 5,
                backgroundColor: '#fff',
                boxShadow: '0 1px 5px rgba(0,0,0,0.1)',
                width: 'calc(33% - 20px)',
                cursor: 'pointer'
              }}
              onClick={() => handleShowPersonalizedPath(course)}
              title="Click to view personalized path"
            >
              <h4 style={{margin:'0 0 10px'}}>{course.title}</h4>
              <div style={{ fontSize: '0.9em', color: '#666' }}>Provider: {course.provider}</div>
              <div style={{ fontSize: '0.85em', color: '#999' }}>Duration: {course.duration_hours} hours</div>
              <button
                onClick={(e) => { e.stopPropagation(); handleSelectCourse(course); }}
                style={{ marginTop: 10, padding: '6px 12px', backgroundColor: '#007bff', border: 'none', color: 'white', borderRadius: 5, cursor: 'pointer' }}
              >
                Add to Learning Path
              </button>
            </div>
          ))}
        </div>
      </section>
      {personalizedPath.length > 0 && (
        <section style={{marginTop: '2rem', background: '#f6fff9', borderRadius: 12, padding: 18, boxShadow: '0 1px 8px rgba(40,167,69,0.05)'}}>
          <h3 style={{color: "#007bff"}}>Personalized Path for Selected Course</h3>
          {personalizedPath.map((c, idx) => (
            <div key={idx} style={{margin:'16px 0',padding:'12px',background:idx===0?'#e8f5fd':'#fff',borderRadius:8,boxShadow:'0 1px 3px rgba(0,0,0,0.06)'}}>
              <b>{c.title}</b> {" "}<span style={{color: "#888"}}>({c.provider})</span>
              <div>Duration: {c.duration_hours} hours | Days to complete: <b>{c.days_to_complete}</b></div>
              <div>Similarity Score: {c.similarity}</div>
              <a href={c.url} target="_blank" rel="noopener noreferrer" style={{color: "#007bff"}}>Go to Course</a>
            </div>
          ))}
        </section>
      )}
    </div>
  );
};

export default Dashboard;